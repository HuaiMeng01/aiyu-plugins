// ===== 自动生成，请勿手改（源码见 hub2/src）=====

// ============================================================
// 纯 JS 的 ZIP 解包内核（无依赖，Node 与 QuickJS 通用）
// 用途：L2 方案里把下载到的插件 zip 解开，写进 App 的 modules 目录
// 实现：RFC1951 inflate（store / fixed / dynamic）+ ZIP 中央目录解析
// ============================================================

(function (root, factory) {
    var api = factory();
    if (typeof module === 'object' && module.exports) module.exports = api;
    else root.AiyuUnzip = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {

    // ---------- 位读取（LSB first） ----------
    function BitReader(data, start, end) {
        this.d = data;
        this.p = start;
        this.end = end === undefined ? data.length : end;
        this.bitBuf = 0;
        this.bitCnt = 0;
    }
    BitReader.prototype.bit = function () {
        if (this.bitCnt === 0) {
            if (this.p >= this.end) throw new Error('unexpected end of deflate stream');
            this.bitBuf = this.d[this.p++];
            this.bitCnt = 8;
        }
        var b = this.bitBuf & 1;
        this.bitBuf >>>= 1;
        this.bitCnt--;
        return b;
    };
    BitReader.prototype.bits = function (n) {
        var v = 0;
        for (var i = 0; i < n; i++) v |= this.bit() << i;
        return v;
    };
    BitReader.prototype.alignByte = function () {
        this.bitCnt = 0;
        this.bitBuf = 0;
    };

    // ---------- Huffman ----------
    function buildHuffman(lengths) {
        var count = new Array(16);
        for (var i = 0; i < 16; i++) count[i] = 0;
        for (var j = 0; j < lengths.length; j++) count[lengths[j]]++;
        count[0] = 0;

        var offs = new Array(16);
        offs[1] = 0;
        for (var k = 1; k < 15; k++) offs[k + 1] = offs[k] + count[k];

        var symbol = new Array(lengths.length);
        for (var m = 0; m < lengths.length; m++) {
            if (lengths[m]) symbol[offs[lengths[m]]++] = m;
        }
        return { count: count, symbol: symbol };
    }

    function decodeSymbol(br, h) {
        var code = 0, first = 0, index = 0;
        for (var len = 1; len <= 15; len++) {
            code |= br.bit();
            var cnt = h.count[len];
            if (code - first < cnt) return h.symbol[index + (code - first)];
            index += cnt;
            first = (first + cnt) << 1;
            code <<= 1;
        }
        throw new Error('invalid huffman code');
    }

    var LEN_BASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
        35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
    var LEN_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
        3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
    var DIST_BASE = [1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193,
        257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577];
    var DIST_EXTRA = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
        7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];

    var FIXED_LIT = null;
    var FIXED_DIST = null;

    function fixedTables() {
        if (FIXED_LIT) return;
        var lit = new Array(288);
        for (var i = 0; i < 288; i++) {
            lit[i] = i < 144 ? 8 : i < 256 ? 9 : i < 280 ? 7 : 8;
        }
        FIXED_LIT = buildHuffman(lit);
        var dist = new Array(30);
        for (var j = 0; j < 30; j++) dist[j] = 5;
        FIXED_DIST = buildHuffman(dist);
    }

    /** 输出缓冲：按需扩容 */
    function OutBuf(hint) {
        this.buf = new Uint8Array(hint > 0 ? hint : 1024);
        this.len = 0;
    }
    OutBuf.prototype.ensure = function (extra) {
        if (this.len + extra <= this.buf.length) return;
        var size = this.buf.length;
        while (size < this.len + extra) size *= 2;
        var nb = new Uint8Array(size);
        nb.set(this.buf.subarray(0, this.len));
        this.buf = nb;
    };
    OutBuf.prototype.push = function (byte) {
        this.ensure(1);
        this.buf[this.len++] = byte;
    };
    OutBuf.prototype.copy = function (dist, len) {
        if (dist > this.len) throw new Error('invalid distance ' + dist);
        this.ensure(len);
        var from = this.len - dist;
        for (var i = 0; i < len; i++) {
            this.buf[this.len++] = this.buf[from + i];
        }
    };
    OutBuf.prototype.bytes = function () {
        return this.buf.subarray(0, this.len);
    };

    /** 解压原始 deflate 流 */
    function inflateRaw(data, start, end) {
        var br = new BitReader(data, start, end);
        var out = new OutBuf(4096);
        var last = 0;

        while (!last) {
            last = br.bit();
            var type = br.bits(2);

            if (type === 0) {
                // stored
                br.alignByte();
                var len = data[br.p] | (data[br.p + 1] << 8);
                br.p += 4; // 跳过 LEN + NLEN
                out.ensure(len);
                for (var s = 0; s < len; s++) out.push(data[br.p++]);
            } else if (type === 1) {
                fixedTables();
                inflateBlock(br, out, FIXED_LIT, FIXED_DIST);
            } else if (type === 2) {
                var tables = readDynamicTables(br);
                inflateBlock(br, out, tables.lit, tables.dist);
            } else {
                throw new Error('invalid deflate block type');
            }
        }
        return out.bytes();
    }

    function readDynamicTables(br) {
        var hlit = br.bits(5) + 257;
        var hdist = br.bits(5) + 1;
        var hclen = br.bits(4) + 4;

        var order = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];
        var clen = new Array(19);
        for (var i = 0; i < 19; i++) clen[i] = 0;
        for (var j = 0; j < hclen; j++) clen[order[j]] = br.bits(3);

        var clHuff = buildHuffman(clen);
        var lengths = new Array(hlit + hdist);
        var n = 0;

        while (n < hlit + hdist) {
            var sym = decodeSymbol(br, clHuff);
            if (sym < 16) {
                lengths[n++] = sym;
            } else if (sym === 16) {
                var rep = br.bits(2) + 3;
                var prev = lengths[n - 1];
                while (rep-- > 0) lengths[n++] = prev;
            } else if (sym === 17) {
                var r17 = br.bits(3) + 3;
                while (r17-- > 0) lengths[n++] = 0;
            } else {
                var r18 = br.bits(7) + 11;
                while (r18-- > 0) lengths[n++] = 0;
            }
        }

        return {
            lit: buildHuffman(lengths.slice(0, hlit)),
            dist: buildHuffman(lengths.slice(hlit))
        };
    }

    function inflateBlock(br, out, litHuff, distHuff) {
        while (true) {
            var sym = decodeSymbol(br, litHuff);
            if (sym === 256) return;
            if (sym < 256) {
                out.push(sym);
                continue;
            }
            var li = sym - 257;
            if (li >= 29) throw new Error('invalid length symbol');
            var len = LEN_BASE[li] + br.bits(LEN_EXTRA[li]);
            var dsym = decodeSymbol(br, distHuff);
            var dist = DIST_BASE[dsym] + br.bits(DIST_EXTRA[dsym]);
            out.copy(dist, len);
        }
    }

    // ---------- ZIP 解析 ----------

    function u16(d, o) { return d[o] | (d[o + 1] << 8); }
    function u32(d, o) { return (d[o] | (d[o + 1] << 8) | (d[o + 2] << 16)) + d[o + 3] * 16777216; }

    function findEOCD(d) {
        var min = Math.max(0, d.length - 65557);
        for (var i = d.length - 22; i >= min; i--) {
            if (d[i] === 0x50 && d[i + 1] === 0x4b && d[i + 2] === 0x05 && d[i + 3] === 0x06) {
                return i;
            }
        }
        return -1;
    }

    /** 解码文件名（UTF-8 或 ASCII） */
    function decodeName(d, start, len) {
        var out = '';
        var i = start;
        var end = start + len;
        while (i < end) {
            var c = d[i++];
            if (c < 0x80) {
                out += String.fromCharCode(c);
            } else if (c >= 0xc0 && c < 0xe0) {
                var c2 = d[i++] & 0x3f;
                out += String.fromCharCode(((c & 0x1f) << 6) | c2);
            } else if (c >= 0xe0 && c < 0xf0) {
                var c3 = d[i++] & 0x3f, c4 = d[i++] & 0x3f;
                out += String.fromCharCode(((c & 0x0f) << 12) | (c3 << 6) | c4);
            } else {
                var c5 = d[i++] & 0x3f, c6 = d[i++] & 0x3f, c7 = d[i++] & 0x3f;
                var cp = ((c & 0x07) << 18) | (c5 << 12) | (c6 << 6) | c7;
                cp -= 0x10000;
                out += String.fromCharCode(0xd800 + (cp >> 10), 0xdc00 + (cp & 0x3ff));
            }
        }
        return out;
    }

    /**
     * 解压整个 zip
     * @returns [{ name, data:Uint8Array, size }]
     */
    function unzip(d) {
        if (!(d instanceof Uint8Array)) {
            if (d && d.buffer) d = new Uint8Array(d.buffer, d.byteOffset, d.byteLength);
            else throw new Error('input must be Uint8Array');
        }
        var eocd = findEOCD(d);
        if (eocd === -1) throw new Error('not a zip: end of central directory not found');

        var total = u16(d, eocd + 10);
        var cdOffset = u32(d, eocd + 16);
        var p = cdOffset;
        var files = [];

        for (var i = 0; i < total; i++) {
            if (u32(d, p) !== 0x02014b50) throw new Error('bad central directory header');
            var method = u16(d, p + 10);
            var compSize = u32(d, p + 20);
            var uncompSize = u32(d, p + 24);
            var nameLen = u16(d, p + 28);
            var extraLen = u16(d, p + 30);
            var commentLen = u16(d, p + 32);
            var localOff = u32(d, p + 42);
            var name = decodeName(d, p + 46, nameLen);

            // 本地头，定位真实数据起点
            if (u32(d, localOff) !== 0x04034b50) throw new Error('bad local header: ' + name);
            var lNameLen = u16(d, localOff + 26);
            var lExtraLen = u16(d, localOff + 28);
            var dataStart = localOff + 30 + lNameLen + lExtraLen;

            var content;
            if (name.charAt(name.length - 1) === '/') {
                content = new Uint8Array(0); // 目录项
            } else if (method === 0) {
                content = d.subarray(dataStart, dataStart + compSize);
            } else if (method === 8) {
                content = inflateRaw(d, dataStart, dataStart + compSize);
            } else {
                throw new Error('unsupported compression method ' + method + ' for ' + name);
            }

            if (uncompSize && content.length !== uncompSize) {
                throw new Error('size mismatch for ' + name + ': ' + content.length + ' != ' + uncompSize);
            }

            files.push({ name: name, data: content, size: content.length });
            p += 46 + nameLen + extraLen + commentLen;
        }
        return files;
    }

    /** Uint8Array → UTF-8 字符串 */
    function utf8Decode(d) {
        var out = '';
        for (var i = 0; i < d.length; i++) {
            var c = d[i];
            if (c < 0x80) out += String.fromCharCode(c);
            else if (c < 0xe0) out += String.fromCharCode(((c & 0x1f) << 6) | (d[++i] & 0x3f));
            else if (c < 0xf0) out += String.fromCharCode(((c & 0x0f) << 12) | ((d[++i] & 0x3f) << 6) | (d[++i] & 0x3f));
            else {
                var cp = ((c & 0x07) << 18) | ((d[++i] & 0x3f) << 12) | ((d[++i] & 0x3f) << 6) | (d[++i] & 0x3f);
                cp -= 0x10000;
                out += String.fromCharCode(0xd800 + (cp >> 10), 0xdc00 + (cp & 0x3ff));
            }
        }
        return out;
    }

    return { unzip: unzip, inflateRaw: inflateRaw, utf8Decode: utf8Decode };
});


// ============================================================
// 插件安装内核（QuickJS 与 WebView 共用）
// 依赖：AiyuUnzip（unzip / utf8Decode）
// 提供：HubInstaller.install(host, opts) / preflight(host)
// ============================================================

(function (root) {
    var U = root.AiyuUnzip;
    var PING = 'https://raw.githubusercontent.com/octocat/Hello-World/master/README';

    // ---------- 编码工具 ----------

    function utf8Encode(s) {
        var out = [], i, c;
        for (i = 0; i < s.length; i++) {
            c = s.charCodeAt(i);
            if (c < 0x80) out.push(c);
            else if (c < 0x800) {
                out.push(0xc0 | (c >> 6), 0x80 | (c & 0x3f));
            } else if (c >= 0xd800 && c <= 0xdbff && i + 1 < s.length) {
                var c2 = s.charCodeAt(++i);
                var cp = 0x10000 + ((c - 0xd800) << 10) + (c2 - 0xdc00);
                out.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3f),
                         0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
            } else {
                out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 0x3f), 0x80 | (c & 0x3f));
            }
        }
        return new Uint8Array(out);
    }

    /** 判断是否像文本：能按 UTF-8 走通、无 NUL、控制字符极少 */
    function looksText(bytes) {
        if (!bytes || !bytes.length) return true;
        if (bytes.length > 4 * 1024 * 1024) return false;
        var i = 0, bad = 0, n = bytes.length;
        while (i < n) {
            var c = bytes[i];
            if (c === 0) return false;
            if (c < 0x80) {
                if (c < 0x09 || (c > 0x0d && c < 0x20)) bad++;
                i++;
                continue;
            }
            var need = 0;
            if ((c & 0xe0) === 0xc0) need = 1;
            else if ((c & 0xf0) === 0xe0) need = 2;
            else if ((c & 0xf8) === 0xf0) need = 3;
            else return false;                     // 非法起始字节
            if (i + need >= n) return false;
            for (var k = 1; k <= need; k++) {
                if ((bytes[i + k] & 0xc0) !== 0x80) return false;
            }
            i += need + 1;
        }
        return bad * 20 < n;
    }

    function sameBytes(a, b) {
        if (!a || !b || a.length !== b.length) return false;
        var step = a.length > 4096 ? 7 : 1;
        for (var i = 0; i < a.length; i += step) if (a[i] !== b[i]) return false;
        return true;
    }

    function baseName(p) {
        var s = String(p);
        var i = s.lastIndexOf('/');
        return i === -1 ? s : s.substring(i + 1);
    }

    function dirName(p) {
        var s = String(p).replace(/\/+$/, '');
        var i = s.lastIndexOf('/');
        return i === -1 ? '' : s.substring(0, i);
    }

    // ---------- zip 解析 ----------

    function locateRoot(files) {
        // 找到最浅的 manifest.json，把它所在目录当作包根
        var best = null;
        for (var i = 0; i < files.length; i++) {
            var n = files[i].name.replace(/^\.\//, '');
            if (baseName(n).toLowerCase() !== 'manifest.json') continue;
            var depth = n.split('/').length;
            if (!best || depth < best.depth) best = { name: n, depth: depth };
        }
        if (!best) return null;
        return dirName(best.name);   // '' 表示就在根上
    }

    function safeRelPath(p, rootPrefix) {
        var n = String(p).replace(/^\.\//, '');
        if (rootPrefix) {
            if (n.indexOf(rootPrefix + '/') !== 0) return null;
            n = n.substring(rootPrefix.length + 1);
        }
        if (!n || n.charAt(n.length - 1) === '/') return null;   // 目录项
        if (n.indexOf('..') !== -1) return null;
        if (n.charAt(0) === '/') return null;
        if (/^[A-Za-z]:/.test(n)) return null;
        if (n.indexOf('\\') !== -1) return null;
        if (n.length > 180) return null;
        return n;
    }

    // ---------- 安装 ----------

    /**
     * opts: { url, zipBytes?, expectId?, log? }
     * 返回 { ok, id, name, version, files, log[], error }
     */
    function install(host, opts) {
        var log = [];
        function say(s) { log.push(s); if (opts.onLog) opts.onLog(s); }

        function fail(msg) {
            return { ok: false, error: msg, log: log };
        }

        try {
            // 1) 取 zip
            var bytes = opts.zipBytes;
            if (!bytes) {
                if (!opts.url) return fail('没有下载地址');
                var tmpDir = tempDir(host);
                var tmp = tmpDir + '/.hub_dl_' + (new Date().getTime ? new Date().getTime() : 1) + '.zip';
                say('下载中…');
                var dres = host.download(opts.url, tmp);
                if (!dres) {
                    return fail('下载失败：' + (host.lastDownloadError || 'downloadFile 返回空') + '\n目录：' + tmpDir);
                }
                bytes = host.read(tmp);
                host.del(tmp);
                if (!bytes || !bytes.length) return fail('下载到的文件读不出来');
                say('已下载 ' + bytes.length + ' 字节');
            }

            // 2) 解包
            var files;
            try {
                files = U.unzip(bytes);
            } catch (e) {
                return fail('解压失败：' + e.message);
            }
            say('解出 ' + files.length + ' 个文件');

            var prefix = locateRoot(files);
            if (prefix === null) return fail('包里没有 manifest.json');

            // 3) 读 manifest
            var manifest = null;
            for (var i = 0; i < files.length; i++) {
                var rel0 = safeRelPath(files[i].name, prefix);
                if (rel0 === 'manifest.json') {
                    try {
                        manifest = JSON.parse(U.utf8Decode(files[i].data));
                    } catch (e) {
                        return fail('manifest.json 不是合法 JSON');
                    }
                }
            }
            if (!manifest) return fail('读不到 manifest.json');

            var id = String(manifest.id || '');
            if (!/^[A-Za-z0-9_.-]{1,64}$/.test(id)) return fail('manifest.id 不合法：' + id);
            if (opts.expectId && id !== opts.expectId) {
                return fail('包内 id（' + id + '）与索引（' + opts.expectId + '）不一致');
            }
            say('插件：' + (manifest.name || id) + ' v' + (manifest.version || '?'));

            // entry 检查
            var names = {};
            for (var k = 0; k < files.length; k++) {
                var rk = safeRelPath(files[k].name, prefix);
                if (rk) names[rk] = true;
            }
            if (manifest.entry && !names[manifest.entry]) {
                return fail('entry 指向的文件不存在：' + manifest.entry);
            }
            if (manifest.js_entry && !names[manifest.js_entry]) {
                return fail('js_entry 指向的文件不存在：' + manifest.js_entry);
            }

            // 4) 目标目录
            var parent = dirName(host.moduleDir());
            if (!parent || parent.charAt(0) !== '/') return fail('拿不到模块根目录');
            var target = parent + '/' + id;

            if (host.exists(target)) {
                return fail('已安装同名插件（' + id + '），请在模块列表卸载后重试');
            }
            say('目标目录：' + target);

            // 5) 写文件
            var written = [], skipped = [], total = 0;
            for (var j = 0; j < files.length; j++) {
                var rel = safeRelPath(files[j].name, prefix);
                if (!rel) continue;
                var data = files[j].data;
                if (!data) data = new Uint8Array(0);
                var full = target + '/' + rel;
                var res = host.write(full, data);
                if (res !== 'ok') {
                    skipped.push(rel + '（' + res + '）');
                    continue;
                }
                written.push(rel);
                total += data.length;
            }

            if (!written.length) {
                rollback(host, target, written);
                return fail('一个文件都没写进去，可能是目录不可写');
            }
            if (skipped.length && skipped.length === written.length) {
                rollback(host, target, written);
                return fail('全部写入校验失败');
            }

            say('写入 ' + written.length + ' 个文件，共 ' + total + ' 字节');
            if (skipped.length) say('跳过 ' + skipped.length + ' 个：' + skipped.join('; '));

            // 6) 回读校验 manifest
            var check = host.read(target + '/manifest.json');
            if (!check) {
                rollback(host, target, written);
                return fail('写入后读不到 manifest.json');
            }

            return {
                ok: true, id: id, name: manifest.name || id,
                version: manifest.version || '', target: target,
                files: written.length, skipped: skipped, log: log
            };
        } catch (e) {
            return fail('异常：' + (e && e.message ? e.message : String(e)));
        }
    }

    /** 找一个确实存在的目录放临时文件（模块目录一定存在） */
    function tempDir(host) {
        var cands = [host.moduleDir(), host.cacheDir()];
        for (var i = 0; i < cands.length; i++) {
            var d = cands[i];
            if (!d) continue;
            try { if (host.exists(d)) return d; } catch (e) {}
        }
        return cands[0];
    }

    function rollback(host, target, written) {
        for (var i = 0; i < written.length; i++) {
            try { host.del(target + '/' + written[i]); } catch (e) {}
        }
        try { host.del(target + '/manifest.json'); } catch (e) {}
    }

    // ---------- 自检 ----------

    function preflight(host) {
        var out = [];
        function add(name, fn) {
            var r;
            try { r = fn(); } catch (e) { r = { ok: false, detail: e.message }; }
            out.push({ name: name, ok: !!r.ok, detail: r.detail || '' });
        }

        add('读取模块目录', function () {
            var d = host.moduleDir();
            return { ok: !!d && d.charAt(0) === '/', detail: d };
        });

        add('自家目录可写', function () {
            var p = host.moduleDir() + '/.hub_probe';
            var payload = utf8Encode('probe-ok');
            var w = host.write(p, payload);
            var back = host.read(p);
            host.del(p);
            var extra = (host.lastWriteLog || []).join(' | ');
            return { ok: w === 'ok' && sameBytes(back, payload), detail: w + (extra ? '　[' + extra + ']' : '') };
        });

        add('父目录可写', function () {
            var parent = dirName(host.moduleDir());
            var p = parent + '/.hub_probe_' + Math.random().toString(36).substring(2, 8);
            var payload = utf8Encode('probe-ok');
            var w = host.write(p, payload);
            var back = host.read(p);
            host.del(p);
            return { ok: w === 'ok' && sameBytes(back, payload), detail: parent + ' → ' + w };
        });

        add('列出同级模块', function () {
            var parent = dirName(host.moduleDir());
            var list = host.list(parent);
            return {
                ok: list && list.length > 0,
                detail: (list || []).slice(0, 6).join(', ') || '空'
            };
        });

        add('下载通道', function () {
            var dirs = [host.moduleDir(), host.cacheDir()];
            var last = '';
            for (var i = 0; i < dirs.length; i++) {
                var d = dirs[i];
                if (!d) continue;
                var p = d + '/.hub_probe_dl_' + i;
                var ok = host.download(PING, p);
                var b = ok ? host.read(p) : null;
                host.del(p);
                if (b && b.length > 0) return { ok: true, detail: b.length + ' 字节（' + d + '）' };
                last = (host.lastDownloadError || '失败') + ' @ ' + d;
            }
            return { ok: false, detail: last || '失败' };
        });

        return out;
    }

    root.HubInstaller = { install: install, preflight: preflight, utf8Encode: utf8Encode, looksText: looksText, sameBytes: sameBytes };
})(typeof globalThis !== 'undefined' ? globalThis : this);


// ============================================================
// QuickJS 侧的主机适配器
// 把 AiyuNative 的不确定签名收敛成固定接口，供 HubInstaller 使用
// ============================================================

(function (root) {
    var UI = root.HubInstaller;

    function bytes(v) {
        if (v === null || v === undefined) return null;
        if (typeof v === 'string') return fromString(v);
        if (typeof v === 'object') {
            if (v.length !== undefined && typeof v !== 'function') {
                // 数组 / Uint8Array
                var out = new Uint8Array(v.length);
                for (var i = 0; i < v.length; i++) out[i] = v[i] & 0xff;
                return out;
            }
            if (v.data) return bytes(v.data);
            if (v.value) return bytes(v.value);
            if (v.bytes) return bytes(v.bytes);
        }
        return null;
    }

    function fromString(s) {
        if (s.length > 4 && s.charCodeAt(0) === 0x50 && s.charCodeAt(1) === 0x4b) {
            return latin1ToBytes(s);              // 以 PK 开头：原始字节
        }
        var t = s.replace(/^[\r\n\t ]+|[\r\n\t ]+$/g, '');
        if (t.length > 16 && t.length % 4 === 0 && /^[A-Za-z0-9+\/=]+$/.test(t)) {
            try { return b64decode(t); } catch (e) {}
        }
        return latin1ToBytes(s);                  // 原样，绝不裁剪
    }

    function latin1ToBytes(s) {
        var a = new Uint8Array(s.length);
        for (var i = 0; i < s.length; i++) a[i] = s.charCodeAt(i) & 0xff;
        return a;
    }

    function b64decode(s) {
        var B = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        function idx(ch) { return ch === '=' ? -1 : B.indexOf(ch); }
        var clean = String(s).replace(/[\r\n\t ]/g, '');
        var out = [], i = 0;
        while (i < clean.length) {
            var c1 = idx(clean.charAt(i++));
            var c2 = idx(clean.charAt(i++));
            if (c1 < 0 || c2 < 0) break;
            out.push((c1 << 2) | (c2 >> 4));
            if (i >= clean.length) break;
            var c3 = idx(clean.charAt(i++));
            if (c3 < 0) break;
            out.push(((c2 & 15) << 4) | (c3 >> 2));
            if (i >= clean.length) break;
            var c4 = idx(clean.charAt(i++));
            if (c4 < 0) break;
            out.push(((c3 & 3) << 6) | c4);
        }
        return new Uint8Array(out);
    }
    function toB64(u8) {
        var B = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        var out = '', i;
        for (i = 0; i + 2 < u8.length; i += 3) {
            var n = (u8[i] << 16) | (u8[i + 1] << 8) | u8[i + 2];
            out += B.charAt((n >> 18) & 63) + B.charAt((n >> 12) & 63) +
                   B.charAt((n >> 6) & 63) + B.charAt(n & 63);
        }
        var left = u8.length - i;
        if (left === 1) {
            var a = u8[i] << 16;
            out += B.charAt((a >> 18) & 63) + B.charAt((a >> 12) & 63) + '==';
        } else if (left === 2) {
            var b = (u8[i] << 16) | (u8[i + 1] << 8);
            out += B.charAt((b >> 18) & 63) + B.charAt((b >> 12) & 63) +
                   B.charAt((b >> 6) & 63) + '=';
        }
        return out;
    }

    function latin1(u8) {
        var s = '';
        for (var i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
        return s;
    }

    var Host = {
        moduleDir: function () {
            try { return String(AiyuNative.getModuleDir()); } catch (e) { return ''; }
        },
        cacheDir: function () {
            try {
                var d = AiyuNative.getModuleCacheDir();
                if (d) return String(d);
            } catch (e) {}
            return Host.moduleDir() + '/.cache';
        },
        exists: function (p) {
            try { return !!AiyuNative.fileExists(p); } catch (e) { return false; }
        },
        list: function (p) {
            try {
                var r = AiyuNative.listFiles(p);
                if (!r) return [];
                if (r.length !== undefined && typeof r !== 'string') {
                    var out = [];
                    for (var i = 0; i < r.length; i++) out.push(String(r[i]));
                    return out;
                }
                var s = String(r);
                try { var arr = JSON.parse(s); if (arr && arr.length !== undefined) return arr; } catch (e) {}
                return s.split(/[\n,]/).filter(function (x) { return x && x.length; });
            } catch (e) { return []; }
        },
        read: function (p) {
            try { return bytes(AiyuNative.readFile(p)); } catch (e) { return null; }
        },
        lastDownloadError: '',

        download: function (url, path) {
            Host.lastDownloadError = '';
            var r;
            try {
                r = AiyuNative.downloadFile(url, path);
            } catch (e) {
                Host.lastDownloadError = 'throw: ' + ((e && e.message) || e);
                return false;
            }
            if (r === false) { Host.lastDownloadError = 'returned false'; return false; }
            if (typeof r === 'string' && r && r.length && r !== path) {
                // 某些实现会返回落盘路径
                if (r.indexOf('/') !== -1) path = r;
            }
            if (r && typeof r === 'object') {
                if (r.success === false || r.ok === false) {
                    Host.lastDownloadError = String(r.message || r.error || 'success=false');
                    return false;
                }
            }
            if (!Host.exists(path)) {
                Host.lastDownloadError = 'file not found: ' + path;
                return false;
            }
            return true;
        },

        /** 最近一次写入的尝试记录，供自检展示 */
        lastWriteLog: [],

        write: function (p, u8) {
            var tries = [];
            var isText = UI.looksText(u8);
            var rel = '';
            try {
                var md = Host.moduleDir();
                if (md && p.indexOf(md + '/') === 0) rel = p.substring(md.length + 1);
            } catch (e) {}

            if (isText) tries.push({ name: 'text', path: p, data: AiyuUnzip.utf8Decode(u8) });
            tries.push({ name: 'bytes', path: p, data: u8 });
            tries.push({ name: 'b64', path: p, data: toB64(u8) });
            if (rel) {
                if (isText) tries.push({ name: 'rel-text', path: rel, data: AiyuUnzip.utf8Decode(u8) });
                tries.push({ name: 'rel-b64', path: rel, data: toB64(u8) });
            }

            Host.lastWriteLog.length = 0;
            for (var i = 0; i < tries.length; i++) {
                var t = tries[i];
                var err = '';
                try {
                    AiyuNative.writeFile(t.path, t.data);
                } catch (e) {
                    err = (e && e.message) ? e.message : 'throw';
                }
                var exists = false;
                try { exists = !!AiyuNative.fileExists(p); } catch (e) {}
                var ok = false;
                if (exists) {
                    try { ok = verify(p, u8); } catch (e) {}
                }
                Host.lastWriteLog.push(t.name + ':' + (err ? 'err(' + err + ')' : (ok ? 'ok' : 'mismatch')) + (exists ? '' : '/nofile'));
                if (ok) return 'ok';
                if (err && err.indexOf('denied') !== -1) break;
            }

            try { Host.del(p); } catch (e) {}
            return 'write failed';
        },

        del: function (p) {
            try { return !!AiyuNative.deleteFile(p); } catch (e) { return false; }
        },
        toast: function (m) { try { AiyuNative.showToast(m); } catch (e) {} },
        log: function (m) { try { AiyuNative.log(m); } catch (e) {} }
    };

    function verify(p, want) {
        var back = Host.read(p);
        return UI.sameBytes(back, want);
    }

    root.AiyuHost = Host;
})(typeof globalThis !== 'undefined' ? globalThis : this);


// ============================================================
// 爱语插件源 v1.1.0  (engine: quickjs)
// 作用：在聊天里浏览 / 审查 / 获取 GitHub 上的爱语插件
// 命令：<pkg:list> <pkg:info 名称> <pkg:url 名称>
//       <pkg:source 地址> <pkg:src> <pkg:install 名称>
// 说明：只负责发现与校验，安装仍走 App 的「插件管理 → 本地导入」
// v1.1.0：新增 GitHub 代理回退链（代理 → jsDelivr → 直连）
// ============================================================

var VERSION = '2.1.0';

var KEY_SOURCE = 'source_url';
var KEY_CACHE = 'index_cache';
var KEY_CACHE_AT = 'index_cache_at';
var KEY_PROXY = 'proxy_list';
var KEY_PROXY_ON = 'proxy_enabled';
var KEY_LAST = 'last_route';
var KEY_CHOICE = 'proxy_choice';

// 实测可用性（2026-11）：gh-proxy.com / gh.dpik.top / edgeone.gh-proxy.org 可用
var DEFAULT_PROXIES = [
    'https://gh-proxy.com',
    'https://gh.dpik.top',
    'https://edgeone.gh-proxy.org',
    'https://hk.gh-proxy.com'
];

// 代理连通性测试用的固定小文件
var PING_URL = 'https://raw.githubusercontent.com/octocat/Hello-World/master/README';

// ---------- 基础工具 ----------

function str(v) {
    if (v === null || v === undefined) return '';
    try { return String(v); } catch (e) { return ''; }
}

function trim(s) { return str(s).replace(/^\s+|\s+$/g, ''); }

function tryParse(text) {
    try { return JSON.parse(text); } catch (e) { return null; }
}

function now() {
    try { return Date.now(); } catch (e) { return 0; }
}

/**
 * 爱语的原生接口会用信封包装返回值：
 *   {"success":true,"key":"source_url","value":"HuaiMeng01/aiyu-plugins"}
 * 把内层真实值取出来；不是信封则返回 null
 */
function envelope(o) {
    if (!o || typeof o !== 'object' || o.length !== undefined) return null;
    var wrapped = (('value' in o) || ('data' in o) || ('body' in o) || ('text' in o));
    if (!wrapped) return null;
    var flagged = (o.success === true || o.success === false || o.ok === true ||
                   o.key !== undefined || o.code !== undefined);
    if (!flagged) return null;
    if ('value' in o) return o.value;
    if ('data' in o) return o.data;
    if ('body' in o) return o.body;
    return o.text;
}

/** 逐层剥信封，直到拿到字符串或真正的对象 */
function unpeel(v, depth) {
    var d = depth || 0;
    if (d > 3 || v === null || v === undefined) return v;
    if (typeof v === 'string') {
        var t = trim(v);
        if (t.charAt(0) === '{') {
            var o = tryParse(t);
            var inner = envelope(o);
            if (inner !== null && inner !== undefined) return unpeel(inner, d + 1);
        }
        return v;
    }
    if (typeof v === 'object') {
        var inner2 = envelope(v);
        if (inner2 !== null && inner2 !== undefined) return unpeel(inner2, d + 1);
    }
    return v;
}

/** 统一成字符串（对象则序列化） */
function textOf(v) {
    var u = unpeel(v, 0);
    if (u === null || u === undefined) return '';
    if (typeof u === 'object') {
        try { return JSON.stringify(u); } catch (e) { return ''; }
    }
    return str(u);
}

/** httpGet 的返回结构在不同版本可能是 string / {body} / {data} / 信封，统一成字符串 */
function httpText(url) {
    var r;
    try {
        r = AiyuNative.httpGet(url);
    } catch (e) {
        return { error: 'request failed: ' + e.message };
    }
    if (r === null || r === undefined) return { error: 'empty response' };

    var u = unpeel(r, 0);
    if (u === null || u === undefined) return { error: 'empty response' };
    if (typeof u === 'string') return { text: u };
    if (typeof u === 'object') {
        if (typeof u.body === 'string') return { text: u.body, code: u.code || u.status };
        if (typeof u.text === 'string') return { text: u.text, code: u.code || u.status };
        if (typeof u.data === 'string') return { text: u.data, code: u.code || u.status };
        if (u.data && typeof u.data === 'object') return { data: u.data };
        return { text: JSON.stringify(u) };
    }
    return { text: str(u) };
}

function hostOf(u) {
    return str(u).replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
}

/** 从任意写法里剥掉代理前缀，拿到真实地址 */
function stripProxy(s) {
    var v = trim(s);
    // https://gh-proxy.com/https://raw.githubusercontent.com/...
    var m = v.match(/^https?:\/\/[^\/]+\/(https?:\/\/.+)$/i);
    if (m) return m[1];
    return v;
}

function isGithubUrl(u) {
    return /^https?:\/\/(raw\.githubusercontent\.com|github\.com|codeload\.github\.com|objects\.githubusercontent\.com)\//i.test(str(u));
}

// ---------- 代理配置 ----------

function getProxies() {
    var on = str(safeGet(KEY_PROXY_ON));
    if (on === '0') return [];
    var raw = str(safeGet(KEY_PROXY));
    if (!raw) return DEFAULT_PROXIES.slice(0);
    var arr = tryParse(raw);
    if (!arr || arr.length === undefined) return DEFAULT_PROXIES.slice(0);
    var out = [];
    for (var i = 0; i < arr.length; i++) {
        var p = trim(arr[i]);
        if (p) out.push(p.replace(/\/+$/, ''));
    }
    return out;
}

function setProxies(arr) {
    safeSet(KEY_PROXY, JSON.stringify(arr));
    safeSet(KEY_PROXY_ON, arr.length ? '1' : '0');
    safeSet(KEY_LAST, '');
}

function proxiesOn() { return str(safeGet(KEY_PROXY_ON)) !== '0'; }

// ---------- 通道（页面里选，AI 不需要知道） ----------

function currentChannel() {
    var v = str(safeGet(KEY_CHOICE));
    if (!v || v === 'auto') return 'auto';
    if (v === 'direct' || v === 'jsdelivr') return v;
    if (/^https?:\/\//i.test(v)) return v.replace(/\/+$/, '');
    return 'auto';
}

function setChannel(id) {
    safeSet(KEY_CHOICE, trim(id) || 'auto');
    safeSet(KEY_LAST, '');       // 换通道后重排
}

/** 页面用的通道清单 */
function listChannels() {
    var out = [{ id: 'auto', name: '自动' }];
    var ps = getProxies();
    for (var i = 0; i < ps.length; i++) out.push({ id: ps[i], name: hostOf(ps[i]) });
    out.push({ id: 'jsdelivr', name: 'jsDelivr' });
    out.push({ id: 'direct', name: '直连' });
    return out;
}

function channelName(id) {
    var list = listChannels();
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i].name;
    if (id === 'auto') return '自动';
    return hostOf(id) || id;
}

/** 把一个通道的测速结果做成一句话 */
function testChannel(id) {
    var ping = PING_URL;
    var url;
    if (id === 'direct') url = ping;
    else if (id === 'jsdelivr') url = 'https://cdn.jsdelivr.net/gh/octocat/Hello-World@master/README';
    else if (id === 'auto') url = '';
    else url = id.replace(/\/+$/, '') + '/' + ping;

    if (!url) return { ok: false, ms: 0, detail: '自动模式不单独测速' };

    var t0 = now();
    var r = httpText(url);
    var ms = now() - t0;
    if (r.error) return { ok: false, ms: ms, detail: r.error };
    var body = str(r.text);
    if (!body || body.length < 3) return { ok: false, ms: ms, detail: '空响应' };
    return { ok: true, ms: ms, detail: body.length + ' 字节' };
}

// ---------- 路由 ----------

function readLast() {
    var raw = str(safeGet(KEY_LAST));
    if (!raw) return null;
    return tryParse(raw);
}

function saveLast(key, branch, label) {
    safeSet(KEY_LAST, JSON.stringify({ key: key, branch: branch, label: label }));
}

function lastLabel() {
    var l = readLast();
    return l && l.label ? l.label : '';
}

/** 代理通道：(前缀)/(raw 地址)，带 main/master 两个分支 */
function makeProxyTransport(prefix, rawBase) {
    var p = prefix.replace(/\/+$/, '');
    return {
        key: 'proxy|' + p,
        label: hostOf(p),
        build: function (b) { return p + '/' + rawBase + b + '/plugins.json'; }
    };
}

/**
 * 通道排序：页面里选中的通道排第一，其次上次成功的，再按默认顺序。
 * 选「自动」时完全按上次成功优先。
 */
function orderTransports(transports) {
    var choice = currentChannel();
    var out = [], used = {}, i;

    function take(t) {
        if (!t || used[t.key]) return;
        used[t.key] = 1;
        out.push(t);
    }

    if (choice !== 'auto') {
        var want = (choice === 'direct') ? 'raw'
                 : (choice === 'jsdelivr') ? 'jsdelivr'
                 : 'proxy|' + choice;
        for (i = 0; i < transports.length; i++) {
            if (transports[i].key === want) take(transports[i]);
        }
    }

    var last = readLast();
    if (last && last.key) {
        for (i = 0; i < transports.length; i++) {
            if (transports[i].key === last.key) take(transports[i]);
        }
    }

    for (i = 0; i < transports.length; i++) take(transports[i]);
    return out;
}

/** owner/repo → 候选（每个通道 main / master 两次） */
function routeList(owner, repo) {
    var proxies = getProxies();
    var rawBase = 'https://raw.githubusercontent.com/' + owner + '/' + repo + '/';
    var jsdBase = 'https://cdn.jsdelivr.net/gh/' + owner + '/' + repo + '@';

    function rawUrl(b) { return rawBase + b + '/plugins.json'; }
    function jsdUrl(b) { return jsdBase + b + '/plugins.json'; }

    var transports = [];
    for (var i = 0; i < proxies.length; i++) {
        transports.push(makeProxyTransport(proxies[i], rawBase));
    }
    transports.push({ key: 'jsdelivr', label: 'jsDelivr', build: jsdUrl });
    transports.push({ key: 'raw', label: '直连 raw', build: rawUrl });

    transports = orderTransports(transports);

    var last = readLast();
    var branches = ['main', 'master'];
    if (last && last.branch === 'master') branches = ['master', 'main'];

    var out = [];
    for (var k = 0; k < transports.length; k++) {
        for (var b = 0; b < branches.length; b++) {
            out.push({
                url: transports[k].build(branches[b]),
                key: transports[k].key,
                label: transports[k].label,
                branch: branches[b]
            });
        }
    }
    return out;
}

/** raw 地址 → jsDelivr 等价地址（不能转换则返回空） */
function jsdOf(rawUrl) {
    var m = str(rawUrl).match(/^https?:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/([^\/]+)\/(.+)$/i);
    if (!m) return '';
    return 'https://cdn.jsdelivr.net/gh/' + m[1] + '/' + m[2] + '@' + m[3] + '/' + m[4];
}

/**
 * 任意入口地址 → 候选列表
 * 支持 owner/repo、github.com/owner/repo、raw 链接、jsdelivr 链接
 */
function buildCandidates(input) {
    var s = stripProxy(input);
    if (!s) return [];

    // github.com/owner/repo 页面地址
    var mPage = s.match(/github\.com\/([^\/\s]+)\/([^\/\s#?]+)/i);
    if (mPage && !/raw\.githubusercontent|jsdelivr/i.test(s)) {
        return routeList(mPage[1], mPage[2].replace(/\.git$/, ''));
    }

    // owner/repo
    var m = s.match(/^([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)$/);
    if (m) return routeList(m[1], m[2]);

    // 已经是完整文件地址
    if (/^https?:\/\//i.test(s)) {
        var out = [], used = {};

        function add(url, key, label) {
            if (!url || used[key]) return;
            used[key] = 1;
            out.push({ url: url, key: key, label: label, branch: '' });
        }

        if (isGithubUrl(s)) {
            var choice = currentChannel();
            var proxies = getProxies();

            if (choice !== 'auto' && choice !== 'direct' && choice !== 'jsdelivr') {
                add(choice + '/' + s, 'proxy|' + choice, hostOf(choice));
            }
            var last = readLast();
            if (last && last.key.indexOf('proxy|') === 0) {
                add(last.key.substring(6) + '/' + s, last.key, hostOf(last.key.substring(6)));
            }
            for (var i = 0; i < proxies.length; i++) {
                var p = proxies[i].replace(/\/+$/, '');
                add(p + '/' + s, 'proxy|' + p, hostOf(p));
            }
            var jd = jsdOf(s);
            if (jd) add(jd, 'jsdelivr', 'jsDelivr');
        }

        add(s, 'direct', hostOf(s));
        return out;
    }

    return [];
}

// ---------- 拉索引 ----------

var lastRawPreview = '';

function b64ToBytes(t) {
    var B = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
    var clean = str(t).replace(/[\r\n\t ]/g, '');
    var out = [], i = 0;
    function idx(ch) { return ch === '=' ? -1 : B.indexOf(ch); }
    while (i < clean.length) {
        var c1 = idx(clean.charAt(i++));
        var c2 = idx(clean.charAt(i++));
        if (c1 < 0 || c2 < 0) break;
        out.push((c1 << 2) | (c2 >> 4));
        if (i >= clean.length) break;
        var c3 = idx(clean.charAt(i++));
        if (c3 < 0) break;
        out.push(((c2 & 15) << 4) | (c3 >> 2));
        if (i >= clean.length) break;
        var c4 = idx(clean.charAt(i++));
        if (c4 < 0) break;
        out.push(((c3 & 3) << 6) | c4);
    }
    return new Uint8Array(out);
}

/**
 * 从任意返回结构里挖出索引对象。
 * 兼容：字符串 / 双重编码 / 带前后缀 / base64 / {data}/{body}/{value}/{content} 包装 / 数组
 */
function digJson(v, depth) {
    var d = depth || 0;
    if (d > 5 || v === null || v === undefined) return null;

    if (typeof v === 'string') {
        var t = trim(v);
        if (!t || t.charAt(0) === '<') return null;

        var o = tryParse(t);
        if (o !== null && o !== undefined) {
            var r1 = digJson(o, d + 1);
            if (r1) return r1;
        }

        // 前后有杂字符：截 {} 区间
        var a = t.indexOf('{'), b = t.lastIndexOf('}');
        if (a > 0 || (a === 0 && b < t.length - 1)) {
            if (a !== -1 && b > a) {
                var t2 = t.substring(a, b + 1);
                var o2 = tryParse(t2);
                if (o2 !== null && o2 !== undefined && typeof o2 !== 'string') {
                    var r2 = digJson(o2, d + 1);
                    if (r2) return r2;
                }
            }
        }

        // base64 包裹
        if (t.length > 40 && t.length % 4 === 0 && /^[A-Za-z0-9+\/=]+$/.test(t)) {
            try {
                var dec = AiyuUnzip.utf8Decode(b64ToBytes(t));
                var o3 = tryParse(dec);
                if (o3 !== null && o3 !== undefined && typeof o3 !== 'string') {
                    var r3 = digJson(o3, d + 1);
                    if (r3) return r3;
                }
            } catch (e) {}
        }
        return null;
    }

    if (typeof v === 'object') {
        if (v.plugins && v.plugins.length !== undefined) return v;
        if (v.id && v.version) return v;                     // 单个 manifest
        if (v.length !== undefined) {                        // 数组
            if (v.length && v[0] && (v[0].id || v[0].name)) return { plugins: v };
            if (v.length > 16 && typeof v[0] === 'number') {  // 字节数组
                try {
                    var u8 = new Uint8Array(v.length);
                    for (var bi = 0; bi < v.length; bi++) u8[bi] = v[bi] & 0xff;
                    return digJson(AiyuUnzip.utf8Decode(u8), d + 1);
                } catch (e) {}
            }
            return null;
        }
        var keys = ['data', 'body', 'value', 'text', 'content', 'result', 'response', 'payload'];
        for (var i = 0; i < keys.length; i++) {
            if (v[keys[i]] !== undefined) {
                var r4 = digJson(v[keys[i]], d + 1);
                if (r4) return r4;
            }
        }
    }
    return null;
}

function fetchIndex() {
    var src = str(safeGet(KEY_SOURCE));
    if (!src) return { error: 'NO_SOURCE' };

    var routes = buildCandidates(src);
    if (!routes.length) {
        return { error: '源地址格式不对，应形如 owner/repo 或 https://…/plugins.json' };
    }

    var lastErr = '';
    function note(msg) { if (!lastErr) lastErr = msg; }
    for (var i = 0; i < routes.length; i++) {
        var r = routes[i];
        var res = httpText(r.url);
        if (res.error) { note(r.label + '：' + res.error); continue; }

        var body = str(res.text);
        if (/^\s*<(!DOCTYPE|html)/i.test(body)) {
            lastRawPreview = body.substring(0, 80);
            note(r.label + '：返回的是网页而不是 JSON（仓库私有或路径不对）');
            continue;
        }
        var obj = digJson((res.data !== undefined && res.data !== null) ? res.data : body, 0);

        if (!obj) {
            lastRawPreview = body.substring(0, 140);
            note(r.label + '：没解析出索引（' + (body ? lastRawPreview : '空响应') + '）');
            continue;
        }

        var list = normalize(obj, r.url);
        if (list.length) {
            saveLast(r.key, r.branch, r.label);
            return { list: list, from: r.url, label: r.label, count: list.length };
        }
        note(r.label + '：索引里没有插件条目');
    }
    return { error: lastErr || '拉取失败' };
}

/** 兼容两种结构：{plugins:[...]} 与 单个 manifest */
function normalize(obj, baseUrl) {
    // 相对路径要按「去掉代理前缀的真实地址」补全，
    // 否则缓存里会写死某个代理，换代理后全部失效
    var logicalBase = stripProxy(baseUrl);
    var arr = [];

    if (obj && obj.plugins && obj.plugins.length !== undefined) {
        for (var i = 0; i < obj.plugins.length; i++) arr.push(obj.plugins[i]);
    } else if (obj && obj.length !== undefined && typeof obj !== 'string') {
        for (var a = 0; a < obj.length; a++) arr.push(obj[a]);
    } else if (obj && obj.id && obj.version) {
        arr.push(obj);
    }

    var out = [];
    for (var j = 0; j < arr.length; j++) {
        var it = arr[j] || {};
        if (!it.id && !it.name) continue;
        out.push({
            id: str(it.id || it.name),
            name: str(it.name || it.id),
            version: str(it.version),
            description: str(it.description || ''),
            author: str(it.author || ''),
            zip: resolveUrl(str(it.zip || ''), logicalBase),
            manifest: resolveUrl(str(it.manifest || ''), logicalBase),
            permissions: it.permissions || [],
            repo: str(it.repo || '')
        });
    }
    return out;
}

/** 相对路径按索引所在目录补全（代理前缀会被保留） */
function resolveUrl(u, baseUrl) {
    if (!u) return '';
    if (/^https?:\/\//i.test(u)) return u;
    var idx = baseUrl.lastIndexOf('/');
    if (idx === -1) return u;
    return baseUrl.substring(0, idx + 1) + u.replace(/^\.\//, '');
}

/** 给下载链接套代理（浏览器/下载器能跟随跳转，直连地址兜底） */
function downloadUrl(u) {
    if (!u) return '';
    if (!isGithubUrl(u)) return u;
    var proxies = getProxies();
    if (!proxies.length) return u;

    var p = proxies[0];
    var last = readLast();
    if (last && last.key && last.key.indexOf('proxy|') === 0) {
        var cand = last.key.substring(6);
        if (proxies.indexOf(cand) !== -1) p = cand;
    }
    return p.replace(/\/+$/, '') + '/' + u;
}

/** 读配置：原生接口返回信封，这里统一取内层字符串 */
function safeGet(k) {
    var v;
    try { v = AiyuNative.getModuleSetting(k, ''); } catch (e) { return ''; }
    return textOf(v);
}

/** 原始值，仅诊断用 */
function rawGet(k) {
    try { return AiyuNative.getModuleSetting(k, ''); } catch (e) { return 'ERR: ' + e.message; }
}

function safeSet(k, v) {
    try { AiyuNative.setModuleSetting(k, v); return true; } catch (e) { return false; }
}

function cacheIndex(list, from) {
    safeSet(KEY_CACHE, JSON.stringify({ list: list, from: from }));
}

function readCache() {
    var raw = str(safeGet(KEY_CACHE));
    if (!raw) return null;
    var obj = tryParse(raw);
    if (!obj || !obj.list) return null;
    return obj;
}

function findInList(list, key) {
    var k = str(key).toLowerCase();
    for (var i = 0; i < list.length; i++) {
        var it = list[i];
        if (str(it.id).toLowerCase() === k || str(it.name).toLowerCase() === k) return it;
    }
    for (var j = 0; j < list.length; j++) {
        var s = (str(list[j].id) + ' ' + str(list[j].name)).toLowerCase();
        if (s.indexOf(k) !== -1) return list[j];
    }
    return null;
}

function permText(p) {
    if (!p || p.length === undefined) return '未声明';
    if (!p.length) return '无';
    var out = [];
    for (var i = 0; i < p.length; i++) out.push(str(p[i]));
    return out.join(', ');
}

// ---------- 命令实现 ----------

function cmdList() {
    var idx = fetchIndex();
    if (idx.error === 'NO_SOURCE') {
        return '还没设置插件源。\n' +
               '用法：<pkg:source owner/repo>\n' +
               '例如：<pkg:source yourname/aiyu-plugins>\n' +
               '仓库里放一个 plugins.json 即可（格式见文档）。';
    }
    if (idx.error) {
        return '拉取失败：' + idx.error + '\n当前源：' + str(safeGet(KEY_SOURCE)) +
               '\n可在插件源页面的「加速通道」里换一个。';
    }

    cacheIndex(idx.list, idx.from);

    var lines = ['插件源：' + idx.from, '通道：' + idx.label + '　共 ' + idx.list.length + ' 个', ''];
    for (var i = 0; i < idx.list.length; i++) {
        var it = idx.list[i];
        lines.push((i + 1) + '. ' + it.name + '  v' + it.version);
        if (it.description) lines.push('   ' + it.description);
        if (it.permissions && it.permissions.length) {
            lines.push('   权限：' + permText(it.permissions));
        }
        lines.push('');
    }
    lines.push('详情：<pkg:info 名称>　直链：<pkg:url 名称>');
    return lines.join('\n');
}

function cmdInfo(name) {
    if (!name) return '用法：<pkg:info 插件名>';

    var cache = readCache();
    var list = cache ? cache.list : null;
    if (!list) {
        var idx = fetchIndex();
        if (idx.error) return '拉取失败：' + idx.error;
        list = idx.list;
        cacheIndex(idx.list, idx.from);
    }

    var it = findInList(list, name);
    if (!it) return '没找到「' + name + '」。先 <pkg:list> 看看有哪些。';

    var lines = [];
    lines.push(it.name + '  v' + it.version);
    if (it.id !== it.name) lines.push('ID：' + it.id);
    if (it.author) lines.push('作者：' + it.author);
    if (it.description) lines.push('简介：' + it.description);
    lines.push('权限：' + permText(it.permissions));
    if (it.repo) lines.push('仓库：' + it.repo);
    lines.push('');
    lines.push(warnPermissions(it.permissions));
    lines.push('');
    lines.push('下载：<pkg:url ' + it.name + '>');
    return lines.join('\n');
}

/** 用大白话说明权限风险，装之前看一眼 */
function warnPermissions(p) {
    var map = {
        read_chat_history: '读取你全部聊天记录',
        write_chat_history: '改写聊天记录、往消息里插图',
        read_memory: '读取记忆库',
        write_memory: '写入记忆库',
        access_network: '访问网络、上传下载',
        read_app_files: '读取应用内文件',
        write_app_files: '写入应用内文件',
        inject_system_prompt: '修改 AI 的系统提示词（会改变角色行为）',
        display_floating_window: '在其他应用上层显示悬浮窗',
        set_persona: '切换或修改人设',
        access_chat_with_ai: '以你的身份发起 AI 对话',
        access_persona_settings: '读取人设配置',
        register_instruction: '注册可被 AI 触发的指令'
    };
    var hits = [];
    if (p && p.length) {
        for (var i = 0; i < p.length; i++) {
            var k = str(p[i]);
            if (map[k]) hits.push('· ' + k + ' → ' + map[k]);
        }
    }
    if (!hits.length) return '风险提示：该插件未申请敏感权限。';
    return '风险提示：\n' + hits.join('\n');
}

function cmdUrl(name) {
    if (!name) return '用法：<pkg:url 插件名>';

    var cache = readCache();
    var it = cache ? findInList(cache.list, name) : null;
    if (!it) {
        var idx = fetchIndex();
        if (idx.error) return '拉取失败：' + idx.error;
        cacheIndex(idx.list, idx.from);
        it = findInList(idx.list, name);
    }
    if (!it) return '没找到「' + name + '」。先 <pkg:list> 看看有哪些。';
    if (!it.zip) return '「' + it.name + '」在索引里没有配置 zip 地址。';

    var dl = downloadUrl(it.zip);
    var lines = [];
    lines.push(it.name + '  v' + it.version);
    lines.push(dl);
    if (dl !== it.zip) {
        lines.push('');
        lines.push('直连（代理不通时用）：');
        lines.push(it.zip);
    }
    lines.push('');
    lines.push('装法：复制上面的地址下载 zip → 爱语「插件管理 → 本地导入」选中它。');
    lines.push('装前确认权限：' + permText(it.permissions));
    return lines.join('\n');
}

function cmdSource(value) {
    var v = trim(value);
    if (!v) {
        var cur = str(safeGet(KEY_SOURCE));
        var out = ['当前源：' + (cur || '（未设置）')];
        if (cur) {
            var c = readCache();
            if (c) out.push('缓存条目：' + (c.list ? c.list.length : 0) + ' 个');
            var l = lastLabel();
            if (l) out.push('上次通道：' + l);
        }
        out.push('加速通道：' + channelName(currentChannel()));
        return out.join('\n');
    }
    if (!buildCandidates(v).length) {
        return '地址格式不支持。用 owner/repo 或 https://…/plugins.json';
    }
    safeSet(KEY_SOURCE, stripProxy(v));
    safeSet(KEY_CACHE, '');
    safeSet(KEY_LAST, '');
    return '已切换到：' + stripProxy(v) + '\n用 <pkg:list> 看看里面有什么。';
}

// ---------- 代理管理 ----------

function cmdProxy(arg) {
    var body = trim(arg);
    var sp = body.indexOf(' ');
    var sub = sp === -1 ? body : body.substring(0, sp);
    var val = sp === -1 ? '' : trim(body.substring(sp + 1));

    if (!sub || sub === 'list') return proxyOverview();
    if (sub === 'on') {
        safeSet(KEY_PROXY_ON, '1');
        return '代理已开启（' + getProxies().length + ' 个）';
    }
    if (sub === 'off') {
        safeSet(KEY_PROXY_ON, '0');
        return '代理已关闭，只走 jsDelivr / 直连。\n恢复：<pkg:proxy on>';
    }
    if (sub === 'reset') {
        safeSet(KEY_PROXY, '');
        safeSet(KEY_PROXY_ON, '1');
        safeSet(KEY_LAST, '');
        return '已恢复默认代理列表。\n' + proxyOverview();
    }
    if (sub === 'add') {
        if (!/^https?:\/\//i.test(val)) return '用法：<pkg:proxy add https://xxx.com>';
        var arr = getProxies();
        var p = val.replace(/\/+$/, '');
        if (arr.indexOf(p) !== -1) return '已经在列表里了：' + p;
        arr.push(p);
        setProxies(arr);
        return '已添加：' + p + '\n共 ' + arr.length + ' 个。建议跑一次 <pkg:proxy test> 验证。';
    }
    if (sub === 'del' || sub === 'remove') {
        var arr2 = getProxies();
        var idxNum = parseInt(val, 10);
        var target = '';
        if (!isNaN(idxNum) && idxNum >= 1 && idxNum <= arr2.length) {
            target = arr2[idxNum - 1];
        } else {
            for (var i = 0; i < arr2.length; i++) {
                if (arr2[i].indexOf(val) !== -1) { target = arr2[i]; break; }
            }
        }
        if (!target) return '没找到要删的代理。先 <pkg:proxy> 看编号。';
        var left = [];
        for (var j = 0; j < arr2.length; j++) if (arr2[j] !== target) left.push(arr2[j]);
        setProxies(left);
        return '已删除：' + target + '\n剩 ' + left.length + ' 个。';
    }
    if (sub === 'test') return proxyTest();

    return '代理命令：\n' +
           '<pkg:proxy>                  查看列表\n' +
           '<pkg:proxy test>             逐个测连通\n' +
           '<pkg:proxy add https://xxx>  添加\n' +
           '<pkg:proxy del 2>            按编号删除\n' +
           '<pkg:proxy off | on>         开关\n' +
           '<pkg:proxy reset>            恢复默认';
}

function proxyOverview() {
    var arr = getProxies();
    var lines = ['GitHub 代理：' + (proxiesOn() ? '开启' : '关闭') + '　共 ' + arr.length + ' 个'];
    if (!arr.length) {
        lines.push('（列表为空，只走 jsDelivr / 直连）');
        lines.push('恢复默认：<pkg:proxy reset>');
        return lines.join('\n');
    }
    for (var i = 0; i < arr.length; i++) {
        lines.push(' ' + (i + 1) + '. ' + arr[i]);
    }
    var l = lastLabel();
    if (l) lines.push('上次成功通道：' + l);
    lines.push('');
    lines.push('连通性：<pkg:proxy test>　添加：<pkg:proxy add 地址>');
    return lines.join('\n');
}

function proxyTest() {
    var arr = getProxies();
    if (!arr.length) return '代理列表为空。恢复默认：<pkg:proxy reset>';

    var lines = ['正在测试 ' + arr.length + ' 个代理…', ''];
    var okCount = 0;
    for (var i = 0; i < arr.length; i++) {
        var p = arr[i].replace(/\/+$/, '');
        var t0 = now();
        var res = httpText(p + '/' + PING_URL);
        var ms = now() - t0;
        var body = str(res.text);

        if (!res.error && /Hello World/i.test(body)) {
            okCount++;
            lines.push('✅ ' + hostOf(p) + '　' + ms + 'ms');
            continue;
        }
        if (!res.error && /302|Moved|Found/i.test(body.substring(0, 300))) {
            lines.push('⚠️ ' + hostOf(p) + '　返回 302 跳转，App 内可能不跟随');
        } else if (!res.error && /^\s*</.test(body)) {
            lines.push('❌ ' + hostOf(p) + '　返回网页/错误页');
        } else {
            lines.push('❌ ' + hostOf(p) + '　' + (res.error || '内容不对'));
        }
    }
    lines.push('');
    lines.push(okCount ? '可用 ' + okCount + ' 个。' : '全部不通，可 <pkg:proxy add 地址> 换一个。');
    return lines.join('\n');
}

// ---------- 指令入口 ----------

/** 自检：把「原生返回 → 解析后 → 候选地址 → 实际拉取」整条链路摊开 */

// ---------- 安装 ----------

/** 名称或地址 → 可下载的 zip 地址（已套代理） */
function resolveZipTarget(arg) {
    var v = trim(arg);
    if (!v) return { error: '用法：<pkg:install 插件名 或 zip 地址>' };

    if (/^https?:\/\//i.test(v)) {
        return { url: downloadUrl(stripProxy(v)) };
    }

    var cache = readCache();
    var list = cache ? cache.list : null;
    if (!list) {
        var idx = fetchIndex();
        if (idx.error) return { error: idx.error };
        list = idx.list;
        cacheIndex(idx.list, idx.from);
    }
    var it = findInList(list, v);
    if (!it) return { error: '索引里没有「' + v + '」' };
    if (!it.zip) return { error: '「' + it.name + '」没配 zip 地址' };
    return { url: downloadUrl(it.zip), item: it };
}

function hostAdapter() {
    return (typeof globalThis !== 'undefined' && globalThis.AiyuHost) ? globalThis.AiyuHost : null;
}

function cmdInstall(arg) {
    var host = hostAdapter();
    if (!host) return '安装模块没加载（构建异常）';

    var t = resolveZipTarget(arg);
    if (t.error) return '安装失败：' + t.error;

    var res = HubInstaller.install(host, {
        url: t.url,
        expectId: t.item ? t.item.id : ''
    });

    var lines = [];
    if (res.ok) {
        lines.push('已安装：' + res.name + ' v' + res.version);
        lines.push('目录：' + res.target);
        lines.push('写入 ' + res.files + ' 个文件');
        if (res.skipped && res.skipped.length) {
            lines.push('跳过：' + res.skipped.join('; '));
        }
        lines.push('');
        lines.push('**需要重启爱语**，重启后到「扩展 → 模块」查看。');
        host.toast('已安装 ' + res.name + '，重启爱语生效');
    } else {
        lines.push('安装失败：' + res.error);
        if (res.log && res.log.length) {
            lines.push('');
            lines.push('过程：');
            for (var i = 0; i < res.log.length; i++) lines.push('· ' + res.log[i]);
        }
        lines.push('');
        lines.push('下载地址：' + t.url);
        lines.push('可在插件源页面点「环境自检」看具体原因，或复制上面的链接手动导入。');
    }
    return lines.join('\n');
}

function cmdUninstall(arg) {
    var host = hostAdapter();
    if (!host) return '安装模块没加载';
    var id = trim(arg);
    if (!id) return '用法：<pkg:uninstall 插件id>';

    var parent = str(host.moduleDir()).replace(/\/[^\/]+$/, '');
    var target = parent + '/' + id;
    if (!host.exists(target)) return '没找到模块：' + id;

    if (id === str(AiyuNative.getModuleId ? AiyuNative.getModuleId() : '')) {
        return '不能卸载自己（pkg_hub）';
    }

    var names = host.list(target) || [];
    var removed = 0, failed = [];
    for (var i = 0; i < names.length; i++) {
        var n = names[i];
        if (host.del(target + '/' + n)) removed++;
        else failed.push(n);
    }
    if (host.del(target)) {
        return '已卸载 ' + id + '（删除 ' + removed + ' 项），重启爱语生效。';
    }
    return '删除了 ' + removed + ' 项，但目录还在（' + target + '）' +
           (failed.length ? '，未删：' + failed.join(', ') : '') +
           '\n重启后若仍显示，请手动删除该目录。';
}

function cmdInstalled() {
    var host = hostAdapter();
    if (!host) return '安装模块没加载';
    var parent = str(host.moduleDir()).replace(/\/[^\/]+$/, '');
    var names = host.list(parent) || [];
    if (!names.length) return '模块目录读不出内容：' + parent;

    var lines = ['已安装模块（' + parent + '）：', ''];
    for (var i = 0; i < names.length; i++) {
        var id = names[i];
        var mf = host.read(parent + '/' + id + '/manifest.json');
        var meta = '';
        if (mf) {
            var o = tryParse(AiyuUnzip.utf8Decode(mf));
            if (o) meta = '  ' + str(o.name) + ' v' + str(o.version) +
                          (o.engine ? ' · ' + o.engine : '');
        }
        lines.push((i + 1) + '. ' + id + meta);
    }
    return lines.join('\n');
}

function cmdScan() {
    var host = hostAdapter();
    if (!host) return '安装模块没加载';
    var rows = HubInstaller.preflight(host);
    var lines = ['环境自检', ''];
    var okAll = true;
    for (var i = 0; i < rows.length; i++) {
        var r = rows[i];
        if (!r.ok) okAll = false;
        lines.push((r.ok ? '✅ ' : '❌ ') + r.name + (r.detail ? '　' + r.detail : ''));
    }
    lines.push('');
    if (okAll) {
        lines.push('全部通过，可以 <pkg:install 插件名> 直接装。');
    } else {
        lines.push('有项目未通过。父目录不可写的话，只能走「本地导入」。');
    }
    return lines.join('\n');
}

function cmdDiag() {
    var lines = ['pkg_hub v' + VERSION + ' 自检', ''];

    lines.push('1) 加速通道：' + channelName(currentChannel()));

    var src = str(safeGet(KEY_SOURCE));
    lines.push('2) 源：' + (src || '（空，先设置插件源）'));

    var routes = src ? buildCandidates(src) : [];
    lines.push('3) 候选地址：' + routes.length + ' 条');
    if (routes.length) lines.push('   首个：' + routes[0].url);

    lines.push('4) 代理数：' + (proxiesOn() ? getProxies().length + ' 个' : '已关闭'));

    lastRawPreview = '';
    var idx = fetchIndex();
    if (idx.error) {
        lines.push('5) 拉取：失败 - ' + idx.error);
        if (lastRawPreview) lines.push('   原始返回：' + lastRawPreview);
    } else {
        lines.push('5) 拉取：成功，' + idx.list.length + ' 个，走 ' + idx.label);
    }
    return lines.join('\n');
}

function handlePkg(matchedText) {
    var raw = str(matchedText);
    var m = raw.match(/<pkg:([^>]*)>/);
    var body = m ? trim(m[1]) : '';

    if (!body || body === 'help') {
        return '插件源命令 v' + VERSION + '：\n' +
               '<pkg:list>            浏览当前源\n' +
               '<pkg:info 名称>       查看版本与权限\n' +
               '<pkg:url 名称>        取下载直链\n' +
               '<pkg:source owner/repo>  切换源\n' +
               '<pkg:src>             查看当前源\n' +
               '<pkg:install 名称|地址>  下载并安装\n' +
               '<pkg:installed>       看已装模块\n' +
               '<pkg:uninstall id>    卸载模块\n' +
               '<pkg:scan>            环境自检\n' +
               '<pkg:diag>            自检（源解析 / 拉取）\n' +
               '加速通道请在插件源页面里选。';
    }

    var sp = body.indexOf(' ');
    var cmd = sp === -1 ? body : body.substring(0, sp);
    var arg = sp === -1 ? '' : trim(body.substring(sp + 1));

    try {
        if (cmd === 'list' || cmd === 'ls') return cmdList();
        if (cmd === 'info') return cmdInfo(arg);
        if (cmd === 'url' || cmd === 'dl') return cmdUrl(arg);
        if (cmd === 'source') return cmdSource(arg);
        if (cmd === 'src') return cmdSource('');
        if (cmd === 'proxy') return cmdProxy(arg);
        if (cmd === 'install' || cmd === 'add' || cmd === 'ins') return cmdInstall(arg);
        if (cmd === 'uninstall' || cmd === 'rm' || cmd === 'remove') return cmdUninstall(arg);
        if (cmd === 'installed' || cmd === 'modules') return cmdInstalled();
        if (cmd === 'scan' || cmd === 'check') return cmdScan();
        if (cmd === 'diag' || cmd === 'debug') return cmdDiag();
        return '不认识的命令：' + cmd + '，试 <pkg:help>';
    } catch (e) {
        return '[pkg_hub] 出错：' + e.message;
    }
}




AiyuNative.log('[pkg_hub] v' + VERSION + ' loaded, host=' + (globalThis.AiyuHost ? 'ok' : 'missing'));