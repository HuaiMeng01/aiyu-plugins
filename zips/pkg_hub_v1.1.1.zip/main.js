// ============================================================
// 爱语插件源 v1.1.0  (engine: quickjs)
// 作用：在聊天里浏览 / 审查 / 获取 GitHub 上的爱语插件
// 命令：<pkg:list> <pkg:info 名称> <pkg:url 名称>
//       <pkg:source 地址> <pkg:src> <pkg:proxy …>
// 说明：只负责发现与校验，安装仍走 App 的「插件管理 → 本地导入」
// v1.1.0：新增 GitHub 代理回退链（代理 → jsDelivr → 直连）
// ============================================================

var VERSION = '1.1.1';

var KEY_SOURCE = 'source_url';
var KEY_CACHE = 'index_cache';
var KEY_CACHE_AT = 'index_cache_at';
var KEY_PROXY = 'proxy_list';
var KEY_PROXY_ON = 'proxy_enabled';
var KEY_LAST = 'last_route';

// 实测可用性（2026-11）：gh-proxy.com / gh.dpik.top / edgeone.gh-proxy.org 可用
var DEFAULT_PROXIES = [
    'https://gh-proxy.com',
    'https://gh.dpik.top',
    'https://edgeone.gh-proxy.org',
    'https://hk.gh-proxy.com'
];

// 代理连通性测试用的固定小文件
var PING_URL = 'https://raw.githubusercontent.com/octocat/Hello-World/master/README';

// ---------- 基础工具 ----------

function str(v) {
    if (v === null || v === undefined) return '';
    try { return String(v); } catch (e) { return ''; }
}

function trim(s) { return str(s).replace(/^\s+|\s+$/g, ''); }

function tryParse(text) {
    try { return JSON.parse(text); } catch (e) { return null; }
}

function now() {
    try { return Date.now(); } catch (e) { return 0; }
}

/**
 * 爱语的原生接口会用信封包装返回值：
 *   {"success":true,"key":"source_url","value":"HuaiMeng01/aiyu-plugins"}
 * 把内层真实值取出来；不是信封则返回 null
 */
function envelope(o) {
    if (!o || typeof o !== 'object' || o.length !== undefined) return null;
    var wrapped = (('value' in o) || ('data' in o) || ('body' in o) || ('text' in o));
    if (!wrapped) return null;
    var flagged = (o.success === true || o.success === false || o.ok === true ||
                   o.key !== undefined || o.code !== undefined);
    if (!flagged) return null;
    if ('value' in o) return o.value;
    if ('data' in o) return o.data;
    if ('body' in o) return o.body;
    return o.text;
}

/** 逐层剥信封，直到拿到字符串或真正的对象 */
function unpeel(v, depth) {
    var d = depth || 0;
    if (d > 3 || v === null || v === undefined) return v;
    if (typeof v === 'string') {
        var t = trim(v);
        if (t.charAt(0) === '{') {
            var o = tryParse(t);
            var inner = envelope(o);
            if (inner !== null && inner !== undefined) return unpeel(inner, d + 1);
        }
        return v;
    }
    if (typeof v === 'object') {
        var inner2 = envelope(v);
        if (inner2 !== null && inner2 !== undefined) return unpeel(inner2, d + 1);
    }
    return v;
}

/** 统一成字符串（对象则序列化） */
function textOf(v) {
    var u = unpeel(v, 0);
    if (u === null || u === undefined) return '';
    if (typeof u === 'object') {
        try { return JSON.stringify(u); } catch (e) { return ''; }
    }
    return str(u);
}

/** httpGet 的返回结构在不同版本可能是 string / {body} / {data} / 信封，统一成字符串 */
function httpText(url) {
    var r;
    try {
        r = AiyuNative.httpGet(url);
    } catch (e) {
        return { error: 'request failed: ' + e.message };
    }
    if (r === null || r === undefined) return { error: 'empty response' };

    var u = unpeel(r, 0);
    if (u === null || u === undefined) return { error: 'empty response' };
    if (typeof u === 'string') return { text: u };
    if (typeof u === 'object') {
        if (typeof u.body === 'string') return { text: u.body, code: u.code || u.status };
        if (typeof u.text === 'string') return { text: u.text, code: u.code || u.status };
        if (typeof u.data === 'string') return { text: u.data, code: u.code || u.status };
        if (u.data && typeof u.data === 'object') return { data: u.data };
        return { text: JSON.stringify(u) };
    }
    return { text: str(u) };
}

function hostOf(u) {
    return str(u).replace(/^https?:\/\//i, '').replace(/\/.*$/, '');
}

/** 从任意写法里剥掉代理前缀，拿到真实地址 */
function stripProxy(s) {
    var v = trim(s);
    // https://gh-proxy.com/https://raw.githubusercontent.com/...
    var m = v.match(/^https?:\/\/[^\/]+\/(https?:\/\/.+)$/i);
    if (m) return m[1];
    return v;
}

function isGithubUrl(u) {
    return /^https?:\/\/(raw\.githubusercontent\.com|github\.com|codeload\.github\.com|objects\.githubusercontent\.com)\//i.test(str(u));
}

// ---------- 代理配置 ----------

function getProxies() {
    var on = str(safeGet(KEY_PROXY_ON));
    if (on === '0') return [];
    var raw = str(safeGet(KEY_PROXY));
    if (!raw) return DEFAULT_PROXIES.slice(0);
    var arr = tryParse(raw);
    if (!arr || arr.length === undefined) return DEFAULT_PROXIES.slice(0);
    var out = [];
    for (var i = 0; i < arr.length; i++) {
        var p = trim(arr[i]);
        if (p) out.push(p.replace(/\/+$/, ''));
    }
    return out;
}

function setProxies(arr) {
    safeSet(KEY_PROXY, JSON.stringify(arr));
    safeSet(KEY_PROXY_ON, arr.length ? '1' : '0');
    safeSet(KEY_LAST, '');
}

function proxiesOn() { return str(safeGet(KEY_PROXY_ON)) !== '0'; }

// ---------- 路由（上次成功的通道优先） ----------

function readLast() {
    var raw = str(safeGet(KEY_LAST));
    if (!raw) return null;
    return tryParse(raw);
}

function saveLast(key, branch, label) {
    safeSet(KEY_LAST, JSON.stringify({ key: key, branch: branch, label: label }));
}

function lastLabel() {
    var l = readLast();
    return l && l.label ? l.label : '';
}

/**
 * 生成候选请求列表，按「上次成功 → 代理 → jsDelivr → 直连」排序
 * 每个通道内先 main 再 master
 */
function routeList(owner, repo) {
    var proxies = getProxies();
    var rawBase = 'https://raw.githubusercontent.com/' + owner + '/' + repo + '/';
    var jsdBase = 'https://cdn.jsdelivr.net/gh/' + owner + '/' + repo + '@';

    function rawUrl(b) { return rawBase + b + '/plugins.json'; }
    function jsdUrl(b) { return jsdBase + b + '/plugins.json'; }

    var transports = [];
    for (var i = 0; i < proxies.length; i++) {
        transports.push(makeProxyTransport(proxies[i], rawBase));
    }
    transports.push({ key: 'jsdelivr', label: 'jsDelivr', build: jsdUrl });
    transports.push({ key: 'raw', label: '直连 raw', build: rawUrl });

    var branches = ['main', 'master'];
    var last = readLast();

    if (last && last.key) {
        for (var j = 0; j < transports.length; j++) {
            if (transports[j].key === last.key) {
                var t = transports.splice(j, 1)[0];
                transports.unshift(t);
                break;
            }
        }
        if (last.branch === 'master') branches = ['master', 'main'];
    }

    var out = [];
    for (var k = 0; k < transports.length; k++) {
        for (var b = 0; b < branches.length; b++) {
            out.push({
                url: transports[k].build(branches[b]),
                key: transports[k].key,
                label: transports[k].label,
                branch: branches[b]
            });
        }
    }
    return out;
}

/** 代理通道：(前缀)/(raw 地址)，带 main/master 两个分支 */
function makeProxyTransport(prefix, rawBase) {
    var p = prefix.replace(/\/+$/, '');
    return {
        key: 'proxy|' + p,
        label: hostOf(p),
        build: function (b) { return p + '/' + rawBase + b + '/plugins.json'; }
    };
}

/**
 * 任意入口地址 → 候选列表
 * 支持 owner/repo、github.com/owner/repo、raw 链接、jsdelivr 链接
 */
function buildCandidates(input) {
    var s = stripProxy(input);
    if (!s) return [];

    // github.com/owner/repo 页面地址
    var mPage = s.match(/github\.com\/([^\/\s]+)\/([^\/\s#?]+)/i);
    if (mPage && !/raw\.githubusercontent|jsdelivr/i.test(s)) {
        return routeList(mPage[1], mPage[2].replace(/\.git$/, ''));
    }

    // owner/repo
    var m = s.match(/^([A-Za-z0-9_.-]+)\/([A-Za-z0-9_.-]+)$/);
    if (m) return routeList(m[1], m[2]);

    // 已经是完整文件地址：代理包一层 + 原样 + 直连兜底
    if (/^https?:\/\//i.test(s)) {
        var out = [];
        var proxies = getProxies();
        if (isGithubUrl(s)) {
            for (var i = 0; i < proxies.length; i++) {
                var p = proxies[i].replace(/\/+$/, '');
                out.push({ url: p + '/' + s, key: 'proxy|' + p, label: hostOf(p), branch: '' });
            }
        }
        out.push({ url: s, key: 'direct', label: hostOf(s), branch: '' });
        return out;
    }

    return [];
}

// ---------- 拉索引 ----------

function fetchIndex() {
    var src = str(safeGet(KEY_SOURCE));
    if (!src) return { error: 'NO_SOURCE' };

    var routes = buildCandidates(src);
    if (!routes.length) {
        return { error: '源地址格式不对，应形如 owner/repo 或 https://…/plugins.json' };
    }

    var lastErr = '';
    for (var i = 0; i < routes.length; i++) {
        var r = routes[i];
        var res = httpText(r.url);
        if (res.error) { lastErr = r.label + '：' + res.error; continue; }

        var body = str(res.text);
        if (/^\s*<(!DOCTYPE|html)/i.test(body)) {
            lastErr = r.label + '：返回的是网页而不是 JSON（仓库私有或路径不对）';
            continue;
        }

        var obj = res.data || tryParse(body);
        if (!obj) {
            lastErr = r.label + '：返回不是合法 JSON（' + body.substring(0, 60) + '）';
            continue;
        }

        var list = normalize(obj, r.url);
        if (list.length) {
            saveLast(r.key, r.branch, r.label);
            return { list: list, from: r.url, label: r.label, count: list.length };
        }
        lastErr = r.label + '：索引里没有插件条目';
    }
    return { error: lastErr || '拉取失败' };
}

/** 兼容两种结构：{plugins:[...]} 与 单个 manifest */
function normalize(obj, baseUrl) {
    // 相对路径要按「去掉代理前缀的真实地址」补全，
    // 否则缓存里会写死某个代理，换代理后全部失效
    var logicalBase = stripProxy(baseUrl);
    var arr = [];

    if (obj && obj.plugins && obj.plugins.length !== undefined) {
        for (var i = 0; i < obj.plugins.length; i++) arr.push(obj.plugins[i]);
    } else if (obj && obj.id && obj.version) {
        arr.push(obj);
    }

    var out = [];
    for (var j = 0; j < arr.length; j++) {
        var it = arr[j] || {};
        if (!it.id && !it.name) continue;
        out.push({
            id: str(it.id || it.name),
            name: str(it.name || it.id),
            version: str(it.version),
            description: str(it.description || ''),
            author: str(it.author || ''),
            zip: resolveUrl(str(it.zip || ''), logicalBase),
            manifest: resolveUrl(str(it.manifest || ''), logicalBase),
            permissions: it.permissions || [],
            repo: str(it.repo || '')
        });
    }
    return out;
}

/** 相对路径按索引所在目录补全（代理前缀会被保留） */
function resolveUrl(u, baseUrl) {
    if (!u) return '';
    if (/^https?:\/\//i.test(u)) return u;
    var idx = baseUrl.lastIndexOf('/');
    if (idx === -1) return u;
    return baseUrl.substring(0, idx + 1) + u.replace(/^\.\//, '');
}

/** 给下载链接套代理（浏览器/下载器能跟随跳转，直连地址兜底） */
function downloadUrl(u) {
    if (!u) return '';
    if (!isGithubUrl(u)) return u;
    var proxies = getProxies();
    if (!proxies.length) return u;

    var p = proxies[0];
    var last = readLast();
    if (last && last.key && last.key.indexOf('proxy|') === 0) {
        var cand = last.key.substring(6);
        if (proxies.indexOf(cand) !== -1) p = cand;
    }
    return p.replace(/\/+$/, '') + '/' + u;
}

/** 读配置：原生接口返回信封，这里统一取内层字符串 */
function safeGet(k) {
    var v;
    try { v = AiyuNative.getModuleSetting(k, ''); } catch (e) { return ''; }
    return textOf(v);
}

/** 原始值，仅诊断用 */
function rawGet(k) {
    try { return AiyuNative.getModuleSetting(k, ''); } catch (e) { return 'ERR: ' + e.message; }
}

function safeSet(k, v) {
    try { AiyuNative.setModuleSetting(k, v); return true; } catch (e) { return false; }
}

function cacheIndex(list, from) {
    safeSet(KEY_CACHE, JSON.stringify({ list: list, from: from }));
}

function readCache() {
    var raw = str(safeGet(KEY_CACHE));
    if (!raw) return null;
    var obj = tryParse(raw);
    if (!obj || !obj.list) return null;
    return obj;
}

function findInList(list, key) {
    var k = str(key).toLowerCase();
    for (var i = 0; i < list.length; i++) {
        var it = list[i];
        if (str(it.id).toLowerCase() === k || str(it.name).toLowerCase() === k) return it;
    }
    for (var j = 0; j < list.length; j++) {
        var s = (str(list[j].id) + ' ' + str(list[j].name)).toLowerCase();
        if (s.indexOf(k) !== -1) return list[j];
    }
    return null;
}

function permText(p) {
    if (!p || p.length === undefined) return '未声明';
    if (!p.length) return '无';
    var out = [];
    for (var i = 0; i < p.length; i++) out.push(str(p[i]));
    return out.join(', ');
}

// ---------- 命令实现 ----------

function cmdList() {
    var idx = fetchIndex();
    if (idx.error === 'NO_SOURCE') {
        return '还没设置插件源。\n' +
               '用法：<pkg:source owner/repo>\n' +
               '例如：<pkg:source yourname/aiyu-plugins>\n' +
               '仓库里放一个 plugins.json 即可（格式见文档）。';
    }
    if (idx.error) {
        return '拉取失败：' + idx.error + '\n当前源：' + str(safeGet(KEY_SOURCE)) +
               '\n可试试 <pkg:proxy test> 看哪个通道通。';
    }

    cacheIndex(idx.list, idx.from);

    var lines = ['插件源：' + idx.from, '通道：' + idx.label + '　共 ' + idx.list.length + ' 个', ''];
    for (var i = 0; i < idx.list.length; i++) {
        var it = idx.list[i];
        lines.push((i + 1) + '. ' + it.name + '  v' + it.version);
        if (it.description) lines.push('   ' + it.description);
        if (it.permissions && it.permissions.length) {
            lines.push('   权限：' + permText(it.permissions));
        }
        lines.push('');
    }
    lines.push('详情：<pkg:info 名称>　直链：<pkg:url 名称>');
    return lines.join('\n');
}

function cmdInfo(name) {
    if (!name) return '用法：<pkg:info 插件名>';

    var cache = readCache();
    var list = cache ? cache.list : null;
    if (!list) {
        var idx = fetchIndex();
        if (idx.error) return '拉取失败：' + idx.error;
        list = idx.list;
        cacheIndex(idx.list, idx.from);
    }

    var it = findInList(list, name);
    if (!it) return '没找到「' + name + '」。先 <pkg:list> 看看有哪些。';

    var lines = [];
    lines.push(it.name + '  v' + it.version);
    if (it.id !== it.name) lines.push('ID：' + it.id);
    if (it.author) lines.push('作者：' + it.author);
    if (it.description) lines.push('简介：' + it.description);
    lines.push('权限：' + permText(it.permissions));
    if (it.repo) lines.push('仓库：' + it.repo);
    lines.push('');
    lines.push(warnPermissions(it.permissions));
    lines.push('');
    lines.push('下载：<pkg:url ' + it.name + '>');
    return lines.join('\n');
}

/** 用大白话说明权限风险，装之前看一眼 */
function warnPermissions(p) {
    var map = {
        read_chat_history: '读取你全部聊天记录',
        write_chat_history: '改写聊天记录、往消息里插图',
        read_memory: '读取记忆库',
        write_memory: '写入记忆库',
        access_network: '访问网络、上传下载',
        read_app_files: '读取应用内文件',
        write_app_files: '写入应用内文件',
        inject_system_prompt: '修改 AI 的系统提示词（会改变角色行为）',
        display_floating_window: '在其他应用上层显示悬浮窗',
        set_persona: '切换或修改人设',
        access_chat_with_ai: '以你的身份发起 AI 对话',
        access_persona_settings: '读取人设配置',
        register_instruction: '注册可被 AI 触发的指令'
    };
    var hits = [];
    if (p && p.length) {
        for (var i = 0; i < p.length; i++) {
            var k = str(p[i]);
            if (map[k]) hits.push('· ' + k + ' → ' + map[k]);
        }
    }
    if (!hits.length) return '风险提示：该插件未申请敏感权限。';
    return '风险提示：\n' + hits.join('\n');
}

function cmdUrl(name) {
    if (!name) return '用法：<pkg:url 插件名>';

    var cache = readCache();
    var it = cache ? findInList(cache.list, name) : null;
    if (!it) {
        var idx = fetchIndex();
        if (idx.error) return '拉取失败：' + idx.error;
        cacheIndex(idx.list, idx.from);
        it = findInList(idx.list, name);
    }
    if (!it) return '没找到「' + name + '」。先 <pkg:list> 看看有哪些。';
    if (!it.zip) return '「' + it.name + '」在索引里没有配置 zip 地址。';

    var dl = downloadUrl(it.zip);
    var lines = [];
    lines.push(it.name + '  v' + it.version);
    lines.push(dl);
    if (dl !== it.zip) {
        lines.push('');
        lines.push('直连（代理不通时用）：');
        lines.push(it.zip);
    }
    lines.push('');
    lines.push('装法：复制上面的地址下载 zip → 爱语「插件管理 → 本地导入」选中它。');
    lines.push('装前确认权限：' + permText(it.permissions));
    return lines.join('\n');
}

function cmdSource(value) {
    var v = trim(value);
    if (!v) {
        var cur = str(safeGet(KEY_SOURCE));
        var out = ['当前源：' + (cur || '（未设置）')];
        if (cur) {
            var c = readCache();
            if (c) out.push('缓存条目：' + (c.list ? c.list.length : 0) + ' 个');
            var l = lastLabel();
            if (l) out.push('上次通道：' + l);
        }
        out.push('代理：' + (proxiesOn() ? getProxies().length + ' 个（<pkg:proxy> 查看）' : '已关闭'));
        return out.join('\n');
    }
    if (!buildCandidates(v).length) {
        return '地址格式不支持。用 owner/repo 或 https://…/plugins.json';
    }
    safeSet(KEY_SOURCE, stripProxy(v));
    safeSet(KEY_CACHE, '');
    safeSet(KEY_LAST, '');
    return '已切换到：' + stripProxy(v) + '\n用 <pkg:list> 看看里面有什么。';
}

// ---------- 代理管理 ----------

function cmdProxy(arg) {
    var body = trim(arg);
    var sp = body.indexOf(' ');
    var sub = sp === -1 ? body : body.substring(0, sp);
    var val = sp === -1 ? '' : trim(body.substring(sp + 1));

    if (!sub || sub === 'list') return proxyOverview();
    if (sub === 'on') {
        safeSet(KEY_PROXY_ON, '1');
        return '代理已开启（' + getProxies().length + ' 个）';
    }
    if (sub === 'off') {
        safeSet(KEY_PROXY_ON, '0');
        return '代理已关闭，只走 jsDelivr / 直连。\n恢复：<pkg:proxy on>';
    }
    if (sub === 'reset') {
        safeSet(KEY_PROXY, '');
        safeSet(KEY_PROXY_ON, '1');
        safeSet(KEY_LAST, '');
        return '已恢复默认代理列表。\n' + proxyOverview();
    }
    if (sub === 'add') {
        if (!/^https?:\/\//i.test(val)) return '用法：<pkg:proxy add https://xxx.com>';
        var arr = getProxies();
        var p = val.replace(/\/+$/, '');
        if (arr.indexOf(p) !== -1) return '已经在列表里了：' + p;
        arr.push(p);
        setProxies(arr);
        return '已添加：' + p + '\n共 ' + arr.length + ' 个。建议跑一次 <pkg:proxy test> 验证。';
    }
    if (sub === 'del' || sub === 'remove') {
        var arr2 = getProxies();
        var idxNum = parseInt(val, 10);
        var target = '';
        if (!isNaN(idxNum) && idxNum >= 1 && idxNum <= arr2.length) {
            target = arr2[idxNum - 1];
        } else {
            for (var i = 0; i < arr2.length; i++) {
                if (arr2[i].indexOf(val) !== -1) { target = arr2[i]; break; }
            }
        }
        if (!target) return '没找到要删的代理。先 <pkg:proxy> 看编号。';
        var left = [];
        for (var j = 0; j < arr2.length; j++) if (arr2[j] !== target) left.push(arr2[j]);
        setProxies(left);
        return '已删除：' + target + '\n剩 ' + left.length + ' 个。';
    }
    if (sub === 'test') return proxyTest();

    return '代理命令：\n' +
           '<pkg:proxy>                  查看列表\n' +
           '<pkg:proxy test>             逐个测连通\n' +
           '<pkg:proxy add https://xxx>  添加\n' +
           '<pkg:proxy del 2>            按编号删除\n' +
           '<pkg:proxy off | on>         开关\n' +
           '<pkg:proxy reset>            恢复默认';
}

function proxyOverview() {
    var arr = getProxies();
    var lines = ['GitHub 代理：' + (proxiesOn() ? '开启' : '关闭') + '　共 ' + arr.length + ' 个'];
    if (!arr.length) {
        lines.push('（列表为空，只走 jsDelivr / 直连）');
        lines.push('恢复默认：<pkg:proxy reset>');
        return lines.join('\n');
    }
    for (var i = 0; i < arr.length; i++) {
        lines.push(' ' + (i + 1) + '. ' + arr[i]);
    }
    var l = lastLabel();
    if (l) lines.push('上次成功通道：' + l);
    lines.push('');
    lines.push('连通性：<pkg:proxy test>　添加：<pkg:proxy add 地址>');
    return lines.join('\n');
}

function proxyTest() {
    var arr = getProxies();
    if (!arr.length) return '代理列表为空。恢复默认：<pkg:proxy reset>';

    var lines = ['正在测试 ' + arr.length + ' 个代理…', ''];
    var okCount = 0;
    for (var i = 0; i < arr.length; i++) {
        var p = arr[i].replace(/\/+$/, '');
        var t0 = now();
        var res = httpText(p + '/' + PING_URL);
        var ms = now() - t0;
        var body = str(res.text);

        if (!res.error && /Hello World/i.test(body)) {
            okCount++;
            lines.push('✅ ' + hostOf(p) + '　' + ms + 'ms');
            continue;
        }
        if (!res.error && /302|Moved|Found/i.test(body.substring(0, 300))) {
            lines.push('⚠️ ' + hostOf(p) + '　返回 302 跳转，App 内可能不跟随');
        } else if (!res.error && /^\s*</.test(body)) {
            lines.push('❌ ' + hostOf(p) + '　返回网页/错误页');
        } else {
            lines.push('❌ ' + hostOf(p) + '　' + (res.error || '内容不对'));
        }
    }
    lines.push('');
    lines.push(okCount ? '可用 ' + okCount + ' 个。' : '全部不通，可 <pkg:proxy add 地址> 换一个。');
    return lines.join('\n');
}

// ---------- 指令入口 ----------

/** 自检：把「原生返回 → 解析后 → 候选地址 → 实际拉取」整条链路摊开 */
function cmdDiag() {
    var lines = ['pkg_hub v' + VERSION + ' 自检', ''];

    var raw = rawGet(KEY_SOURCE);
    var shown = '';
    try { shown = typeof raw === 'string' ? raw : JSON.stringify(raw); } catch (e) { shown = str(raw); }
    lines.push('1) 原生返回：' + str(shown).substring(0, 100));

    var src = str(safeGet(KEY_SOURCE));
    lines.push('2) 解析后源：' + (src || '（空，需先 <pkg:source owner/repo>）'));

    var routes = src ? buildCandidates(src) : [];
    lines.push('3) 候选地址：' + routes.length + ' 条');
    if (routes.length) lines.push('   首个：' + routes[0].url);

    lines.push('4) 代理配置：' + (proxiesOn() ? getProxies().length + ' 个' : '已关闭'));

    var idx = fetchIndex();
    if (idx.error) {
        lines.push('5) 拉取：失败 - ' + idx.error);
    } else {
        lines.push('5) 拉取：成功，' + idx.list.length + ' 个，通道 ' + idx.label);
    }
    return lines.join('\n');
}

function handlePkg(matchedText) {
    var raw = str(matchedText);
    var m = raw.match(/<pkg:([^>]*)>/);
    var body = m ? trim(m[1]) : '';

    if (!body || body === 'help') {
        return '插件源命令 v' + VERSION + '：\n' +
               '<pkg:list>            浏览当前源\n' +
               '<pkg:info 名称>       查看版本与权限\n' +
               '<pkg:url 名称>        取下载直链\n' +
               '<pkg:source owner/repo>  切换源\n' +
               '<pkg:src>             查看当前源\n' +
               '<pkg:proxy test>      测代理连通性\n' +
               '<pkg:diag>            自检（源解析 / 拉取）';
    }

    var sp = body.indexOf(' ');
    var cmd = sp === -1 ? body : body.substring(0, sp);
    var arg = sp === -1 ? '' : trim(body.substring(sp + 1));

    try {
        if (cmd === 'list' || cmd === 'ls') return cmdList();
        if (cmd === 'info') return cmdInfo(arg);
        if (cmd === 'url' || cmd === 'dl') return cmdUrl(arg);
        if (cmd === 'source') return cmdSource(arg);
        if (cmd === 'src') return cmdSource('');
        if (cmd === 'proxy') return cmdProxy(arg);
        if (cmd === 'diag' || cmd === 'debug') return cmdDiag();
        return '不认识的命令：' + cmd + '，试 <pkg:help>';
    } catch (e) {
        return '[pkg_hub] 出错：' + e.message;
    }
}

AiyuNative.log('[pkg_hub] v' + VERSION + ' loaded');
