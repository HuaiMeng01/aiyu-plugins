// ============================================================
// 图片下载器模块 - QuickJS 入口脚本
// ============================================================
// 职责：
//   1. 注册 <download_image:URL> 自定义指令（hide_in_ui=false，UI可见）
//   2. 当AI输出该指令时，下载图片到聊天图片目录
//   3. 调用 attachImageToLastAssistant 将图片附加到最后一条assistant消息
//   4. 下载失败时输出系统消息告知用户
// ============================================================

/**
 * 处理 <download_image:URL> 指令
 * @param {string} matchedText - 完整匹配文本，如 "<download_image:https://xxx>"
 * @returns {string} 处理结果
 */
function handleDownloadImage(matchedText) {
    // 从完整匹配文本中提取URL（模块自行解析参数，不依赖APP）
    var urlMatch = matchedText.match(/<download_image:([^>]+)>/);
    var url = urlMatch ? urlMatch[1] : '';
    if (!url || url.trim().length === 0) {
        AiyuNative.log('[image_downloader] URL is empty');
        return '[image_downloader] error: empty URL';
    }

    url = url.trim();
    AiyuNative.log('[image_downloader] downloading: ' + url);

    // 下载到聊天图片目录（sent_images），卸载模块后图片仍可用
    var chatImageDir = AiyuNative.getChatImageDir();
    var filename = url.substring(url.lastIndexOf('/') + 1).split('?')[0];
    if (!filename || filename.indexOf('.') === -1) {
        filename = 'img_' + Date.now() + '.jpg';
    }
    var savePath = chatImageDir + '/' + filename;

    var result = AiyuNative.downloadFile(url, savePath);
    var parsed;
    try { parsed = JSON.parse(result); } catch (e) { parsed = null; }

    if (!parsed || !parsed.success) {
        var errMsg = parsed ? (parsed.error || 'unknown error') : 'parse error';
        AiyuNative.log('[image_downloader] download failed: ' + errMsg);
        return '[image_downloader] download failed: ' + errMsg;
    }

    AiyuNative.log('[image_downloader] downloaded to: ' + parsed.path);

    // 将图片附加到最后一条assistant消息
    AiyuNative.attachImageToLastAssistant(parsed.path);

    return '[image_downloader] ok: ' + parsed.path;
}

AiyuNative.log('[image_downloader] main.js loaded');
