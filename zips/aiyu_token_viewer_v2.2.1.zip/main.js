// ============================================================
// Token查看器模块 v2.2.1 - QuickJS 入口脚本（HYBRID 模块）
// ============================================================
// 职责：
//   1. 接收 native 推送的 token_update 通知（含打断/总结场景）
//   2. 写入历史记录 + 累计统计到模块 SharedPreferences
//   3. 查 model_prices 表算本次调用费用
//   4. 返回悬浮窗内容字符串（保持现状不动）
//
// 暴露的全局 handler：
//   onTokenUpdate(promptTokens, completionTokens, totalTokens, cachedTokens, modelName, apiCallType, source)
//      → 返回悬浮窗要显示的内容字符串
//
// apiCallType 取值：
//   - "chat"              正常对话
//   - "summary"           自动/动态总结
//   - "interrupted"       用户打断（有 usage 数据）
//   - "interrupted_no_usage"  用户打断（流中无 usage，只记次数）
//
// source 取值：
//   - "main"              聊天页 MainActivity
//   - "ilink"             微信 ILinkService
//   - "ext"               外部访问 ExtAccessHandler
//
// 数据存储（模块独立 SharedPreferences：module_token_viewer_prefs.xml）：
//   - "history"               JSON 数组（不限条数，30天前的自动归档到 history_archive）
//   - "history_archive"       JSON map<YYYY-MM-DD, {total:{...}, main:{...}, ilink:{...}, ext:{...}}> 30天前归档
//   - "context_size"          上下文大小 K（默认 200）
//   - "total_api_calls"       累计 API 调用次数（含打断）
//   - "total_tokens"          累计总 token
//   - "total_prompt_tokens"   累计输入 token
//   - "total_completion_tokens" 累计输出 token
//   - "total_cached_tokens"   累计缓存命中 token
//   - "total_cost"            累计费用（单位：元）
//   - "total_sources"         JSON map<source, {calls,tokens,prompt,completion,cached,cost}> 按来源累计
//   - "model_prices"          JSON map<modelName, {input_per_m, cached_per_m, output_per_m}>（元/百万 token）
//   - "api_call_counter"      自增调用编号
//   - "daily_stats"           JSON map<YYYY-MM-DD, {total:{...}, main:{...}, ilink:{...}, ext:{...}}> 按天按来源聚合
//   - "stats_first_date"      最早一条记录日期（YYYY-MM-DD），用于趋势时间轴起点
//   - "week_start_mode"       0=周日到周六（默认），1=周一到周日
//   - "fallback_model_name"   旧 APP 用户手填的模型名兜底
//   - "stats_dates_rebuilt"   旧记录补 date 标志
//   - "stats_rebuilt"         重建统计标志（不随清零清除）
// ============================================================

const DEFAULT_CONTEXT_SIZE_K = 200;

// 工具：安全的 JSON parse
function safeParse(str, fallback) {
    try { return JSON.parse(str); } catch (e) { return fallback; }
}

// 工具：获取模块设置（带默认值）
function getSetting(key, defaultValue) {
    const result = AiyuNative.getModuleSetting(key, defaultValue);
    const obj = safeParse(result, {});
    if (obj && obj.success && obj.value !== undefined) {
        return obj.value;
    }
    return defaultValue;
}

// 工具：保存模块设置
function setSetting(key, value) {
    AiyuNative.setModuleSetting(key, value);
}

// 工具：获取历史记录
function loadHistory() {
    const result = getSetting('history', '[]');
    return safeParse(result, []);
}

// 工具：保存历史记录
// ⭐ 不限制条数，超过 30 天的记录按天归档到 history_archive
function saveHistory(history) {
    const now = new Date();
    const cutoff = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 30);
    const cutoffStr = formatDateYMD(cutoff);

    const keep = [];
    const archive = loadHistoryArchive();
    let archived = false;

    for (const r of history) {
        const dateStr = r.date || formatDateYMD(now);
        r.date = dateStr;
        if (dateStr < cutoffStr) {
            // 归档：按天 + 按来源聚合
            if (!archive[dateStr]) {
                archive[dateStr] = {
                    total: zeroStat(),
                    main: zeroStat(),
                    ilink: zeroStat(),
                    ext: zeroStat()
                };
            }
            const src = r.source || 'main';
            const srcKey = (src === 'main' || src === 'ilink' || src === 'ext') ? src : 'main';
            const a = archive[dateStr];
            // 累加到来源
            const s = a[srcKey];
            s.calls += 1; s.tokens += r.totalTokens || 0; s.prompt += r.promptTokens || 0;
            s.completion += r.completionTokens || 0; s.cached += r.cachedTokens || 0;
            if (r.cost !== null && r.cost !== undefined) s.cost += r.cost;
            // 累加到 total
            const t = a.total;
            t.calls += 1; t.tokens += r.totalTokens || 0; t.prompt += r.promptTokens || 0;
            t.completion += r.completionTokens || 0; t.cached += r.cachedTokens || 0;
            if (r.cost !== null && r.cost !== undefined) t.cost += r.cost;
            archived = true;
        } else {
            keep.push(r);
        }
    }

    if (archived) saveHistoryArchive(archive);
    setSetting('history', JSON.stringify(keep));
}

function loadHistoryArchive() {
    return safeParse(getSetting('history_archive', '{}'), {});
}
function saveHistoryArchive(archive) {
    setSetting('history_archive', JSON.stringify(archive));
}

// 工具：读取上下文大小配置（默认 200K）
function loadContextSizeK() {
    const val = getSetting('context_size', String(DEFAULT_CONTEXT_SIZE_K));
    return parseInt(val) || DEFAULT_CONTEXT_SIZE_K;
}

// 工具：读取模型价格表
// 返回 { "model_name": {input_per_m: 0, output_per_m: 0}, ... }
function loadModelPrices() {
    const val = getSetting('model_prices', '{}');
    return safeParse(val, {});
}

// 工具：保存模型价格表
function saveModelPrices(prices) {
    setSetting('model_prices', JSON.stringify(prices));
}

// 工具：读取累计统计（含 sources）
function loadTotals() {
    return {
        api_calls: parseInt(getSetting('total_api_calls', '0')) || 0,
        tokens: parseInt(getSetting('total_tokens', '0')) || 0,
        prompt_tokens: parseInt(getSetting('total_prompt_tokens', '0')) || 0,
        completion_tokens: parseInt(getSetting('total_completion_tokens', '0')) || 0,
        cached_tokens: parseInt(getSetting('total_cached_tokens', '0')) || 0,
        cost: parseFloat(getSetting('total_cost', '0')) || 0,
        sources: safeParse(getSetting('total_sources', '{}'), {})
    };
}

// 工具：保存累计统计（含按来源分别记的 sources）
function saveTotals(totals) {
    setSetting('total_api_calls', String(totals.api_calls));
    setSetting('total_tokens', String(totals.tokens));
    setSetting('total_prompt_tokens', String(totals.prompt_tokens));
    setSetting('total_completion_tokens', String(totals.completion_tokens));
    setSetting('total_cached_tokens', String(totals.cached_tokens));
    setSetting('total_cost', String(totals.cost));
    setSetting('total_sources', JSON.stringify(totals.sources || {}));
}

// 工具：自增并返回调用编号
function nextApiCallId() {
    let counter = parseInt(getSetting('api_call_counter', '0')) || 0;
    counter += 1;
    setSetting('api_call_counter', String(counter));
    return counter;
}

// ==================== 按天聚合统计（趋势时间轴用） ====================

// 工具：格式化日期为 YYYY-MM-DD
function formatDateYMD(d) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
}

// 工具：加载 daily_stats
//   返回 { "YYYY-MM-DD": {calls,tokens,prompt,completion,cached,cost}, ... }
function loadDailyStats() {
    return safeParse(getSetting('daily_stats', '{}'), {});
}

// 工具：保存 daily_stats
function saveDailyStats(stats) {
    setSetting('daily_stats', JSON.stringify(stats));
}

// 工具：把一次调用追加到 daily_stats 的当天条目（按来源分别记）
// daily_stats 结构：{ "YYYY-MM-DD": { main:{calls,tokens,...}, ilink:{...}, ext:{...}, total:{...} } }
function appendToDailyStats(dateStr, source, promptTokens, completionTokens, totalTokens, cachedTokens, cost) {
    const stats = loadDailyStats();
    // ⭐ 兼容旧扁平结构：旧版是 {calls,tokens,...}，新版是 {total:{...}, main:{...}, ...}
    //    遇到旧扁平数据时迁移成新结构（旧数据归入 total + main，因为旧数据来源都是 main）
    if (stats[dateStr] && stats[dateStr].calls !== undefined) {
        const old = stats[dateStr];
        stats[dateStr] = {
            total: { calls: old.calls||0, tokens: old.tokens||0, prompt: old.prompt||0, completion: old.completion||0, cached: old.cached||0, cost: old.cost||0 },
            main: { calls: old.calls||0, tokens: old.tokens||0, prompt: old.prompt||0, completion: old.completion||0, cached: old.cached||0, cost: old.cost||0 },
            ilink: zeroStat(),
            ext: zeroStat()
        };
    }
    if (!stats[dateStr]) {
        stats[dateStr] = { total: zeroStat(), main: zeroStat(), ilink: zeroStat(), ext: zeroStat() };
    }
    const d = stats[dateStr];
    // 按来源记
    const srcKey = (source === 'main' || source === 'ilink' || source === 'ext') ? source : 'main';
    const src = d[srcKey];
    src.calls += 1;
    src.tokens += totalTokens;
    src.prompt += promptTokens;
    src.completion += completionTokens;
    src.cached += cachedTokens;
    if (cost !== null && cost !== undefined) src.cost += cost;
    // total 也记一份
    const t = d.total;
    t.calls += 1;
    t.tokens += totalTokens;
    t.prompt += promptTokens;
    t.completion += completionTokens;
    t.cached += cachedTokens;
    if (cost !== null && cost !== undefined) t.cost += cost;
    saveDailyStats(stats);

    // 更新 stats_first_date
    const firstDate = getSetting('stats_first_date', '');
    if (!firstDate || dateStr < firstDate) {
        setSetting('stats_first_date', dateStr);
    }
}

// 空统计对象
function zeroStat() {
    return { calls: 0, tokens: 0, prompt: 0, completion: 0, cached: 0, cost: 0 };
}

// 工具：读取周起始模式（0=日-六 默认，1=一-日）
function getWeekStartMode() {
    return parseInt(getSetting('week_start_mode', '0')) || 0;
}

// 工具：保存周起始模式
function setWeekStartMode(mode) {
    setSetting('week_start_mode', String(mode));
}

// 工具：根据模型价格表算单次调用费用
//   promptTokens 拆成两部分：缓存命中的按 cached_per_m 算（更便宜），
//   剩余的按 input_per_m 算，completion 全按 output_per_m 算
// 返回 { cost: number|null, priceFound: boolean }
//   cost=null 表示价格表里没找到该模型
function calcCost(modelName, promptTokens, completionTokens, cachedTokens) {
    const prices = loadModelPrices();
    if (!modelName || !prices[modelName]) {
        return { cost: null, priceFound: false };
    }
    const price = prices[modelName];
    const cached = Math.max(0, Number(cachedTokens) || 0);
    const nonCachedPrompt = Math.max(0, promptTokens - cached);
    const inputCost = (nonCachedPrompt / 1000000) * (parseFloat(price.input_per_m) || 0);
    // ⭐ 缓存命中部分按 cached_per_m 算；若用户没填缓存价（0 或缺省），回退按 input_per_m 算
    //    避免用户没填缓存价时缓存部分费用变 0 不准
    const cachedPrice = parseFloat(price.cached_per_m);
    const effectiveCachedPrice = (!isNaN(cachedPrice) && cachedPrice > 0) ? cachedPrice : (parseFloat(price.input_per_m) || 0);
    const cachedCost = (cached / 1000000) * effectiveCachedPrice;
    const outputCost = (completionTokens / 1000000) * (parseFloat(price.output_per_m) || 0);
    return { cost: inputCost + cachedCost + outputCost, priceFound: true };
}

// 工具：构建悬浮窗内容（保持现状不动！主人明确要求不改！）
function buildFloatingContent(promptTokens, completionTokens, totalTokens, contextSizeK, cachedTokens) {
    const contextSize = (contextSizeK || DEFAULT_CONTEXT_SIZE_K) * 1000;
    const percentage = contextSize > 0 ? ((totalTokens / contextSize) * 100).toFixed(1) : '0.0';

    // 第一行：基础 Token 信息
    let content = `📊 Token: ${totalTokens} | 提示: ${promptTokens} | 回复: ${completionTokens} | 占比: ${percentage}%`;

    // 第二行：缓存命中信息（仅 API 返回 cached_tokens 时显示）
    if (cachedTokens && cachedTokens > 0 && promptTokens > 0) {
        const cacheRate = ((cachedTokens / promptTokens) * 100).toFixed(1);
        content += `\n💾 缓存: ${cachedTokens} | 命中率: ${cacheRate}%`;
    }

    return content;
}

// 工具：格式化当前时间 HH:MM:SS
function formatTime() {
    const now = new Date();
    const pad = (n) => n.toString().padStart(2, '0');
    return `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
}

// 工具：格式化费用（保留 4 位，太短补 0）
function formatCost(cost) {
    if (cost === null || cost === undefined) return '-';
    return '¥' + Number(cost).toFixed(4);
}

/**
 * ⭐ 模型名兜底读取（旧版 APP 适配核心）
 *
 * 兜底链：native 传入值 > 新 API getCurrentModelName() > 用户手填的 fallback_model_name
 *
 * 新版 APP：onTokenUpdate 第 5 参 modelName 已带值，直接用
 * 旧版 APP（v2.9.0 及以下）：onTokenUpdate 只传 4 参，modelName=undefined
 *   → 尝试调新 API AiyuNative.getCurrentModelName()（旧 APP 没这方法会抛异常）
 *   → 读不到 → 用 HTML 配置页用户手填的 fallback_model_name
 *
 * @param modelNameParam  onTokenUpdate 收到的第 5 参数
 * @returns {string}      最终模型名，可能为空字符串
 */
function resolveModelName(modelNameParam) {
    // 1. native 传入值优先
    if (modelNameParam) {
        return String(modelNameParam);
    }
    // 2. 尝试新 APP 的免权限 API（旧 APP 没这个方法会抛异常，catch 后继续）
    try {
        if (typeof AiyuNative.getCurrentModelName === 'function') {
            const r = AiyuNative.getCurrentModelName();
            if (r) {
                const obj = safeParse(r, {});
                if (obj && obj.modelName) return String(obj.modelName);
            }
        }
    } catch (e) {
        // 旧 APP 没这方法，静默跳过
    }
    // 3. 用户手填的 fallback（HTML 配置页里填，存模块独立 SharedPreferences）
    return getSetting('fallback_model_name', '');
}

/**
 * ⭐ 主 handler：native 收到 usage 后调用
 *
 * @param promptTokens      prompt token 数
 * @param completionTokens  completion token 数
 * @param totalTokens       总 token 数
 * @param cachedTokens      缓存命中的 prompt token 数（部分 API 返回，可能为 0 或未传）
 * @param modelName         模型名（可为空字符串；旧 APP 不传此参）
 * @param apiCallType       调用类型：chat / summary / interrupted / interrupted_no_usage
 * @param source            来源：main(聊天页) / ilink(微信) / ext(外部访问)；旧 APP 不传此参缺省 main
 * @returns {string}        悬浮窗要显示的内容字符串（保持现状）
 *
 * ⭐ 旧版 APP（v2.9.0 及以下）适配：
 *   - arguments.length < 5 表示旧 APP 只传 4 参（不传 modelName + apiCallType + source）
 *   - 旧 APP 模块自己走 resolveModelName 兜底链读模型名
 *   - 旧 APP 不支持打断/微信端调用通知（硬限制，模块无解）
 *   - 模块自己自增 apiCallId（新旧 APP 都一样）
 *   - source 缺省 "main"
 */
function onTokenUpdate(promptTokens, completionTokens, totalTokens, cachedTokens, modelName, apiCallType, source) {
    promptTokens = Number(promptTokens) || 0;
    completionTokens = Number(completionTokens) || 0;
    totalTokens = Number(totalTokens) || 0;
    cachedTokens = Number(cachedTokens) || 0;
    apiCallType = apiCallType ? String(apiCallType) : 'chat';
    source = source ? String(source) : 'main';

    // ⭐ 版本兼容：modelName 走兜底链（旧 APP 不传此参时自动读新 API 或用户手填值）
    const actualModelName = resolveModelName(modelName);

    const contextSizeK = loadContextSizeK();
    const apiCallId = nextApiCallId();

    // 算费用（interrupted_no_usage 时 token 全 0，费用自然 0）
    // ⭐ 把 cachedTokens 传进去，缓存命中部分按 cached_per_m 单价算（更便宜）
    const costResult = calcCost(actualModelName, promptTokens, completionTokens, cachedTokens);
    const cost = costResult.priceFound ? costResult.cost : null;

    // 写历史记录（加 source + date 字段）
    const history = loadHistory();
    const now = new Date();
    history.unshift({
        date: formatDateYMD(now),
        time: formatTime(),
        apiCallId: apiCallId,
        apiCallType: apiCallType,
        source: source,
        modelName: actualModelName,
        promptTokens: promptTokens,
        completionTokens: completionTokens,
        totalTokens: totalTokens,
        cachedTokens: cachedTokens > 0 ? cachedTokens : null,
        cost: cost
    });
    saveHistory(history);

    // 更新累计统计（全局 + 按来源分别记）— 每段独立 try-catch 防止一处异常中断其他写入
    try {
        const totals = loadTotals();
        totals.api_calls += 1;
        totals.tokens += totalTokens;
        totals.prompt_tokens += promptTokens;
        totals.completion_tokens += completionTokens;
        totals.cached_tokens += cachedTokens;
        if (cost !== null) totals.cost += cost;
        if (!totals.sources) totals.sources = {};
        if (!totals.sources[source]) totals.sources[source] = { calls: 0, tokens: 0, prompt: 0, completion: 0, cached: 0, cost: 0 };
        const src = totals.sources[source];
        src.calls += 1;
        src.tokens += totalTokens;
        src.prompt += promptTokens;
        src.completion += completionTokens;
        src.cached += cachedTokens;
        if (cost !== null) src.cost += cost;
        saveTotals(totals);
    } catch (e) {
        AiyuNative.log('[token_viewer] ERROR saveTotals: ' + e.message);
    }

    // ⭐ 追加到按天聚合统计（趋势时间轴用，按来源分别记）
    try {
        appendToDailyStats(formatDateYMD(new Date()), source, promptTokens, completionTokens, totalTokens, cachedTokens, cost);
    } catch (e) {
        AiyuNative.log('[token_viewer] ERROR appendToDailyStats: ' + e.message);
    }

    AiyuNative.log('[token_viewer] onTokenUpdate id=' + apiCallId +
        ' type=' + apiCallType +
        ' source=' + source +
        ' model=' + actualModelName +
        ' total=' + totalTokens +
        ' cached=' + cachedTokens +
        ' cost=' + (cost !== null ? cost.toFixed(4) : 'null'));

    // 悬浮窗内容保持现状
    return buildFloatingContent(promptTokens, completionTokens, totalTokens, contextSizeK, cachedTokens);
}

AiyuNative.log('[token_viewer] main.js v2.2.1 loaded, onTokenUpdate registered');

// ⭐ 一次性修复：给旧 history 记录补 date 字段
//   旧记录没有 date 字段，全部补成今天（它们本来就是今天产生的）
//   用 stats_dates_rebuilt 标志防重复执行
(function rebuildHistoryDates() {
    try {
        const rebuilt = getSetting('stats_dates_rebuilt', '0');
        if (rebuilt === '1') return;
        const history = loadHistory();
        if (history.length === 0) { setSetting('stats_dates_rebuilt', '1'); return; }
        const today = formatDateYMD(new Date());
        let changed = false;
        for (const r of history) {
            if (!r.date) { r.date = today; changed = true; }
        }
        if (changed) saveHistory(history);
        setSetting('stats_dates_rebuilt', '1');
        AiyuNative.log('[token_viewer] rebuilt history dates: ' + history.length + ' records');
    } catch (e) {
        AiyuNative.log('[token_viewer] rebuildHistoryDates error: ' + e.message);
    }
})();

// ⭐ 一次性重建：从 history 重建 totals + daily_stats
//   之前因 appendToDailyStats 抛异常导致 totals/daily_stats 没写入，history 里有完整明细
//   重建后 totals/daily_stats 恢复完整数据，之后的 onTokenUpdate 在此基础上累加
//   用 stats_rebuilt 标志防重复（不随清零清除，清零从 0 开始后也跳过重建）
(function rebuildStatsFromHistory() {
    try {
        const rebuilt = getSetting('stats_rebuilt_v2', '0');
        if (rebuilt === '1') return;
        const history = loadHistory();
        if (history.length === 0) { setSetting('stats_rebuilt', '1'); return; }

        // 重建 totals
        const totals = {
            api_calls: 0, tokens: 0, prompt_tokens: 0, completion_tokens: 0, cached_tokens: 0, cost: 0,
            sources: {}
        };
        // 重建 daily_stats
        const dailyStats = {};
        for (const r of history) {
            const src = r.source || 'main';
            const srcKey = (src === 'main' || src === 'ilink' || src === 'ext') ? src : 'main';
            const dateStr = r.date || formatDateYMD(new Date());
            const totalTokens = r.totalTokens || 0;
            const promptTokens = r.promptTokens || 0;
            const completionTokens = r.completionTokens || 0;
            const cachedTokens = r.cachedTokens || 0;
            const cost = (r.cost !== null && r.cost !== undefined) ? r.cost : 0;

            // totals 全局
            totals.api_calls += 1;
            totals.tokens += totalTokens;
            totals.prompt_tokens += promptTokens;
            totals.completion_tokens += completionTokens;
            totals.cached_tokens += cachedTokens;
            totals.cost += cost;
            // totals sources
            if (!totals.sources[srcKey]) totals.sources[srcKey] = zeroStat();
            const ts = totals.sources[srcKey];
            ts.calls += 1; ts.tokens += totalTokens; ts.prompt += promptTokens;
            ts.completion += completionTokens; ts.cached += cachedTokens; ts.cost += cost;

            // daily_stats 按天
            if (!dailyStats[dateStr]) dailyStats[dateStr] = { total: zeroStat(), main: zeroStat(), ilink: zeroStat(), ext: zeroStat() };
            const d = dailyStats[dateStr];
            const ds = d[srcKey];
            ds.calls += 1; ds.tokens += totalTokens; ds.prompt += promptTokens;
            ds.completion += completionTokens; ds.cached += cachedTokens; ds.cost += cost;
            const dt = d.total;
            dt.calls += 1; dt.tokens += totalTokens; dt.prompt += promptTokens;
            dt.completion += completionTokens; dt.cached += cachedTokens; dt.cost += cost;

            // stats_first_date
        }
        // 更新 stats_first_date
        const dates = Object.keys(dailyStats).sort();
        if (dates.length > 0) setSetting('stats_first_date', dates[0]);

        // 保存
        saveTotals(totals);
        saveDailyStats(dailyStats);
        setSetting('stats_rebuilt_v2', '1');
        AiyuNative.log('[token_viewer] rebuilt stats from history: ' + history.length + ' records, ' + dates.length + ' days');
    } catch (e) {
        AiyuNative.log('[token_viewer] rebuildStatsFromHistory error: ' + e.message);
    }
})();
